// Real backend: auth, storage, click tracking, SEO pages. Zero npm deps (Node 20+).
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const envFile = path.join(root, '.env');
if (fs.existsSync(envFile)) for (const l of fs.readFileSync(envFile, 'utf8').split('\n')) {
  const m = l.match(/^\s*([A-Z_]+)\s*=\s*"?([^"\r]*)"?\s*$/);
  if (m && !(m[1] in process.env)) process.env[m[1]] = m[2];
}
const PORT = +process.env.PORT || 3001;
const SITE = (process.env.SITE_URL || `http://localhost:${PORT}`).replace(/\/$/, '');
const SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
const DATA = path.join(root, 'data'), DB_FILE = path.join(DATA, 'db.json'), UP = path.join(DATA, 'uploads'), DIST = path.join(root, 'dist');
fs.mkdirSync(UP, { recursive: true });

const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const slugify = t => String(t).toLowerCase().trim().replace(/[^\w\s-]/g, '').replace(/[\s_-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60) || 'product';
const hash = (pw, salt = crypto.randomBytes(16).toString('hex')) => salt + ':' + crypto.scryptSync(pw, salt, 32).toString('hex');
const check = (pw, h) => { const [s, x] = h.split(':'); return crypto.timingSafeEqual(Buffer.from(x), Buffer.from(hash(pw, s).split(':')[1])); };

function load() {
  if (fs.existsSync(DB_FILE)) return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  let products = [];
  try { // seed from the sample catalogue (replace these via the admin panel)
    const src = fs.readFileSync(path.join(root, 'src/data/mockProducts.ts'), 'utf8');
    const body = src.split('RAW_PRODUCTS: Product[] =')[1].split(/\n\];/)[0] + '\n]';
    products = new Function('return ' + body)().map(p => ({ ...p, clicksCount: 0, slug: slugify(p.title) }));
  } catch { /* start empty */ }
  let pw = process.env.ADMIN_PASSWORD;
  if (!pw) { pw = crypto.randomBytes(9).toString('base64url'); console.log(`\n  ADMIN PASSWORD (shown once): ${pw}\n`); }
  return { products, clicks: [], settings: { affiliateTag: process.env.AFFILIATE_TAG || 'yourtag-20', siteTitle: 'My Deals Store', contactEmail: 'you@example.com', defaultCommissionRate: 4, estimatedConversionRate: 8.5, passwordHash: hash(pw) } };
}
const db = load();
const save = () => { const t = DB_FILE + '.tmp'; fs.writeFileSync(t, JSON.stringify(db)); fs.renameSync(t, DB_FILE); };
save();

const sign = s => crypto.createHmac('sha256', SECRET).update(s).digest('hex');
const mkTok = () => { const e = Date.now() + 12 * 36e5; return e + '.' + sign('' + e); };
const authed = req => {
  const m = /(?:^|; )sid=([^;]+)/.exec(req.headers.cookie || ''); if (!m) return false;
  const [e, s] = m[1].split('.'); return +e > Date.now() && !!s && s.length === 64 && crypto.timingSafeEqual(Buffer.from(s), Buffer.from(sign(e)));
};
const tries = new Map();
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.json': 'application/json', '.ico': 'image/x-icon', '.woff2': 'font/woff2' };

const send = (res, code, data, type = 'application/json', extra = {}) => {
  res.writeHead(code, { 'Content-Type': type + (/^(text|application\/json)/.test(type) ? '; charset=utf-8' : ''), 'X-Content-Type-Options': 'nosniff', ...extra });
  res.end(typeof data === 'string' || Buffer.isBuffer(data) ? data : JSON.stringify(data));
};
const readBody = req => new Promise((ok, no) => {
  let b = '', n = 0;
  req.on('data', c => { n += c.length; if (n > 8e6) { no(new Error('Body too large')); req.destroy(); } else b += c; });
  req.on('end', () => { try { ok(b ? JSON.parse(b) : {}); } catch (e) { no(new Error('Invalid JSON')); } });
});
const pubSettings = () => { const { passwordHash, ...s } = db.settings; return { ...s, adminPasswordHash: '' }; };
const withTag = url => { const u = new URL(url); u.searchParams.set('tag', db.settings.affiliateTag); return u.toString(); };
const amazonUrl = asin => withTag(`https://www.amazon.com/dp/${asin.toUpperCase()}`);

function clean(input, old = {}) {
  const p = { ...old, ...input }, n = (v, d) => (Number.isFinite(+v) ? +v : d);
  if (!String(p.title || '').trim()) throw new Error('Title is required');
  if (!/^[A-Z0-9]{10}$/i.test(p.asin || '')) throw new Error('A valid 10-character ASIN is required');
  p.price = n(p.price, 0); if (p.price <= 0) throw new Error('Price must be greater than 0');
  p.originalPrice = n(p.originalPrice, 0) > p.price ? n(p.originalPrice, 0) : undefined;
  p.rating = Math.min(5, Math.max(0, n(p.rating, 0)));
  p.reviewCount = Math.max(0, Math.round(n(p.reviewCount, 0)));
  p.commissionRate = Math.min(100, Math.max(0, n(p.commissionRate, db.settings.defaultCommissionRate)));
  p.features = Array.isArray(p.features) ? p.features.map(String).filter(Boolean) : [];
  p.inStock = p.inStock !== false;
  p.id = old.id || p.id || 'prod-' + crypto.randomBytes(5).toString('hex');
  p.clicksCount = old.clicksCount || 0;
  p.affiliateUrl = amazonUrl(p.asin);
  let slug = slugify(p.slug || p.title);
  if (db.products.some(x => x.slug === slug && x.id !== p.id)) slug += '-' + p.id.slice(-4);
  p.slug = slug;
  return p;
}

const page = p => {
  const url = `${SITE}/product/${p.slug}`;
  const img = p.imageUrl?.startsWith('/') ? SITE + p.imageUrl : p.imageUrl;
  const ld = { '@context': 'https://schema.org/', '@type': 'Product', name: p.title, image: [img], description: p.description, sku: p.asin, brand: { '@type': 'Brand', name: p.brand }, offers: { '@type': 'Offer', url, priceCurrency: 'USD', price: p.price.toFixed(2), availability: 'https://schema.org/' + (p.inStock ? 'InStock' : 'OutOfStock') } };
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(p.seoTitle || p.title)}</title><meta name="description" content="${esc((p.seoDescription || p.description || '').slice(0, 160))}">
<link rel="canonical" href="${esc(url)}"><meta property="og:title" content="${esc(p.title)}"><meta property="og:image" content="${esc(img)}">
<script type="application/ld+json">${JSON.stringify(ld).replace(/</g, '\\u003c')}</script>
<style>body{margin:0;font:16px/1.6 system-ui,sans-serif;background:#09090b;color:#e4e4e7}main{max-width:900px;margin:0 auto;padding:24px;display:grid;gap:24px;grid-template-columns:repeat(auto-fit,minmax(280px,1fr))}img{width:100%;border-radius:12px}a{color:#fbbf24}.b{display:inline-block;background:#f59e0b;color:#09090b;font-weight:700;padding:12px 20px;border-radius:10px;text-decoration:none}small{color:#a1a1aa}</style></head>
<body><main><div><img src="${esc(img)}" alt="${esc(p.title)}"></div><div><a href="/">← All deals</a><h1>${esc(p.title)}</h1><p><small>${esc(p.brand)} · ${esc(p.category)}</small></p>
<p style="font-size:28px;font-weight:800">$${p.price.toFixed(2)}${p.originalPrice ? ` <s style="font-size:16px;color:#71717a">$${p.originalPrice.toFixed(2)}</s>` : ''}</p>
<p>${esc(p.description)}</p><ul>${p.features.map(f => `<li>${esc(f)}</li>`).join('')}</ul>
<p><a class="b" href="/r/${esc(p.id)}" rel="sponsored nofollow noopener" target="_blank">View on Amazon</a></p>
<p><small>Price and availability may change. The price shown on Amazon at checkout is final. As an Amazon Associate we earn from qualifying purchases.</small></p></div></main></body></html>`;
};

function serveFile(res, base, rel) {
  const f = path.join(base, path.normalize(rel));
  if (!f.startsWith(base + path.sep) || !fs.existsSync(f) || !fs.statSync(f).isFile()) return false;
  send(res, 200, fs.readFileSync(f), MIME[path.extname(f)] || 'application/octet-stream', { 'Cache-Control': rel.includes('assets') ? 'public, max-age=31536000, immutable' : 'public, max-age=3600' });
  return true;
}

http.createServer(async (req, res) => {
  const p = new URL(req.url, 'http://x').pathname, m = req.method;
  const fail = (c, e) => send(res, c, { error: e });
  const admin = () => authed(req) || (fail(401, 'Admin login required'), false);
  try {
    if (p.startsWith('/api/') && m !== 'GET' && !(req.headers['content-type'] || '').includes('json')) return fail(415, 'JSON required');

    if (p === '/api/products' && m === 'GET') return send(res, 200, db.products, 'application/json', { 'Cache-Control': 'no-cache' });
    if (p === '/api/settings' && m === 'GET') return send(res, 200, pubSettings());
    if (p === '/api/admin/me') return send(res, 200, { ok: authed(req) });

    if (p === '/api/admin/login' && m === 'POST') {
      const ip = req.socket.remoteAddress, t = tries.get(ip) || { n: 0, at: Date.now() };
      if (Date.now() - t.at > 9e5) { t.n = 0; t.at = Date.now(); }
      if (t.n >= 5) return fail(429, 'Too many attempts. Try again in 15 minutes.');
      const { password } = await readBody(req);
      if (typeof password === 'string' && check(password, db.settings.passwordHash)) { tries.delete(ip); return send(res, 200, { ok: true }, 'application/json', { 'Set-Cookie': `sid=${mkTok()}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200${SITE.startsWith('https') ? '; Secure' : ''}` }); }
      t.n++; tries.set(ip, t); return fail(401, 'Incorrect password');
    }
    if (p === '/api/admin/logout' && m === 'POST') return send(res, 200, { ok: true }, 'application/json', { 'Set-Cookie': 'sid=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0' });
    if (p === '/api/admin/clicks') return admin() && send(res, 200, db.clicks.slice(0, 500));

    if (p === '/api/settings' && m === 'PUT') {
      if (!admin()) return;
      const b = await readBody(req), s = db.settings;
      if (b.affiliateTag !== undefined) { if (!/^[a-z0-9-]{3,40}$/i.test(b.affiliateTag)) return fail(400, 'Invalid affiliate tag'); s.affiliateTag = b.affiliateTag; }
      for (const k of ['siteTitle', 'contactEmail']) if (typeof b[k] === 'string') s[k] = b[k].slice(0, 120);
      for (const k of ['defaultCommissionRate', 'estimatedConversionRate']) if (Number.isFinite(+b[k])) s[k] = +b[k];
      if (b.adminPasswordHash) { if (b.adminPasswordHash.length < 8) return fail(400, 'Password must be at least 8 characters'); s.passwordHash = hash(b.adminPasswordHash); }
      save(); return send(res, 200, pubSettings());
    }
    if (p === '/api/admin/bulk-tag' && m === 'POST') {
      if (!admin()) return;
      const { tag } = await readBody(req); if (!/^[a-z0-9-]{3,40}$/i.test(tag || '')) return fail(400, 'Invalid affiliate tag');
      db.settings.affiliateTag = tag; db.products.forEach(x => { x.affiliateUrl = amazonUrl(x.asin); }); save();
      return send(res, 200, { products: db.products });
    }
    if (p === '/api/admin/upload' && m === 'POST') {
      if (!admin()) return;
      const mm = /^data:image\/(png|jpeg|webp);base64,(.+)$/.exec((await readBody(req)).dataUrl || ''); if (!mm) return fail(400, 'PNG, JPG or WebP only');
      const buf = Buffer.from(mm[2], 'base64'); if (buf.length > 5e6) return fail(400, 'Max 5MB');
      const name = crypto.randomBytes(8).toString('hex') + '.' + (mm[1] === 'jpeg' ? 'jpg' : mm[1]);
      fs.writeFileSync(path.join(UP, name), buf); return send(res, 200, { url: '/uploads/' + name });
    }
    if (p === '/api/products' && m === 'POST') { if (!admin()) return; const x = clean(await readBody(req)); db.products.unshift(x); save(); return send(res, 201, x); }
    const pm = /^\/api\/products\/([\w-]+)$/.exec(p);
    if (pm && (m === 'PUT' || m === 'DELETE')) {
      if (!admin()) return;
      const i = db.products.findIndex(x => x.id === pm[1]); if (i < 0) return fail(404, 'Not found');
      if (m === 'DELETE') { db.products.splice(i, 1); save(); return send(res, 200, { ok: true }); }
      db.products[i] = clean(await readBody(req), db.products[i]); save(); return send(res, 200, db.products[i]);
    }
    if (p.startsWith('/api/')) return fail(404, 'Not found');

    // Server-side click tracking + redirect (works with JS off, can't be faked from the browser console)
    const rm = /^\/r\/([\w-]+)$/.exec(p);
    if (rm) {
      const x = db.products.find(y => y.id === rm[1]); if (!x) return send(res, 404, 'Not found', 'text/plain');
      if (!/bot|crawl|spider|slurp/i.test(req.headers['user-agent'] || '')) {
        x.clicksCount = (x.clicksCount || 0) + 1;
        db.clicks.unshift({ id: 'clk-' + Date.now() + '-' + crypto.randomBytes(2).toString('hex'), productId: x.id, productTitle: x.title, productPrice: x.price, commissionRate: x.commissionRate, estimatedCommission: +(x.price * x.commissionRate / 100).toFixed(2), timestamp: new Date().toISOString(), affiliateTag: db.settings.affiliateTag });
        db.clicks.length = Math.min(db.clicks.length, 5000); save();
      }
      return send(res, 302, '', 'text/plain', { Location: withTag(x.affiliateUrl), 'Cache-Control': 'no-store', 'X-Robots-Tag': 'noindex' });
    }
    const sm = /^\/product\/([\w-]+)$/.exec(p);
    if (sm) { const x = db.products.find(y => y.slug === sm[1]); return x ? send(res, 200, page(x), 'text/html') : send(res, 404, 'Not found', 'text/plain'); }
    if (p === '/sitemap.xml') return send(res, 200, `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>${SITE}/</loc></url>${db.products.map(x => `<url><loc>${SITE}/product/${esc(x.slug)}</loc><lastmod>${esc(x.dateAdded || '')}</lastmod></url>`).join('')}</urlset>`, 'application/xml');
    if (p === '/robots.txt') return send(res, 200, `User-agent: *\nDisallow: /r/\nDisallow: /api/\nSitemap: ${SITE}/sitemap.xml\n`, 'text/plain');
    if (p.startsWith('/uploads/')) return serveFile(res, UP, p.slice(9)) || send(res, 404, 'Not found', 'text/plain');
    if (serveFile(res, DIST, p === '/' ? 'index.html' : p.slice(1))) return;
    if (!serveFile(res, DIST, 'index.html')) send(res, 200, 'Frontend not built yet. Run: npm run build', 'text/plain');
  } catch (e) { if (!res.headersSent) fail(400, e.message || 'Bad request'); }
}).listen(PORT, () => console.log(`Store running on ${SITE}`));
