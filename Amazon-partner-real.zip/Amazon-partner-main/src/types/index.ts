export interface Product {
  id: string;
  title: string;
  brand: string;
  category: string;
  price: number;
  originalPrice?: number;
  affiliateUrl: string; // The "Buy Now on Amazon" hyperlink
  asin: string;
  imageUrl: string;
  galleryImages?: string[];
  rating: number;
  reviewCount: number;
  primeEligible: boolean;
  isBestSeller?: boolean;
  isChoice?: boolean;
  commissionRate: number; // e.g. 4.0% (used to calculate affiliate earnings)
  description: string;
  features: string[];
  inStock: boolean;
  clicksCount: number;
  dateAdded: string;
  // Advanced SEO & Viral Google Ranking Attributes
  seoTitle?: string;
  seoDescription?: string;
  seoKeywords?: string[];
  slug?: string;
  seoScore?: number; // 0 - 100
  indexedStatus?: 'Indexed' | 'Queued' | 'Pending';
  lastPingTime?: string;
}

export interface GoogleIndexingLog {
  id: string;
  timestamp: string;
  url: string;
  status: 'SUCCESS' | 'QUEUED' | 'PINGED' | 'ERROR';
  message: string;
}

export interface AffiliateClick {
  id: string;
  productId: string;
  productTitle: string;
  productPrice: number;
  commissionRate: number;
  estimatedCommission: number;
  timestamp: string;
  affiliateTag: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatar: string;
  provider: 'google';
  savedProducts: string[];
  recentClicks: string[];
  createdAt: string;
}

export interface AdminSettings {
  affiliateTag: string;
  adminPasswordHash: string; // Plain/hash for protection
  defaultCommissionRate: number;
  estimatedConversionRate: number; // e.g. 9.5%
  siteTitle: string;
  contactEmail: string;
}

export type CategoryType = 
  | 'All'
  | 'Electronics & Tech'
  | 'Smart Home & Audio'
  | 'Kitchen & Appliances'
  | 'Health & Fitness'
  | 'Workstation & Office'
  | 'Gaming Gear';
