import React, { useState } from 'react';
import { 
  X, 
  Lock, 
  Unlock, 
  Plus, 
  Edit3, 
  Trash2, 
  TrendingUp, 
  DollarSign, 
  MousePointerClick, 
  Percent, 
  Search, 
  Check, 
  AlertCircle, 
  Download, 
  RefreshCw, 
  Link as LinkIcon, 
  ExternalLink,
  ShieldCheck,
  Package,
  Layers,
  Settings,
  ArrowUpRight,
  Terminal,
  Cpu,
  Globe,
  FileCode,
  Share2,
  Sparkles,
  Copy,
  CheckCircle2,
  Play,
  Flame,
  Smartphone,
  Monitor,
  Upload,
  Image as ImageIcon
} from 'lucide-react';
import { api } from '../services/storage';
import { Product, AffiliateClick, AdminSettings } from '../types';
import { 
  generateViralSeoData, 
  auditSeo, 
  generatePythonBotScript, 
  generateSitemapXml, 
  createSlug 
} from '../utils/seoEngine';

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onSaveProduct: (product: Product) => void;
  onDeleteProduct: (productId: string) => void;
  clicks: AffiliateClick[];
  adminSettings: AdminSettings;
  onSaveAdminSettings: (settings: AdminSettings) => void;
  onBulkUpdateAffiliateTag: (newTag: string) => void;
  isAuthenticated: boolean;
  onAuthenticate: (password: string) => Promise<boolean>;
  onLogoutAdmin: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  isOpen,
  onClose,
  products,
  onSaveProduct,
  onDeleteProduct,
  clicks,
  adminSettings,
  onSaveAdminSettings,
  onBulkUpdateAffiliateTag,
  isAuthenticated,
  onAuthenticate,
  onLogoutAdmin,
}) => {
  const [passwordInput, setPasswordInput] = useState('');
  const [authError, setAuthError] = useState('');
  const [activeTab, setActiveTab] = useState<'overview' | 'products' | 'seo-bot' | 'clicks' | 'settings'>('overview');

  // Product form state
  const [isEditingProduct, setIsEditingProduct] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Partial<Product>>({});
  const [productSearch, setProductSearch] = useState('');

  // SEO & SERP Preview state
  const [serpDevice, setSerpDevice] = useState<'desktop' | 'mobile'>('desktop');
  const [keywordInput, setKeywordInput] = useState('');

  // Python Indexer Bot state
  const [botRunning, setBotRunning] = useState(false);
  const [botLogs, setBotLogs] = useState<string[]>([
    '[INIT] Google Search Console Indexing Engine ready.',
    '[STATUS] 12 products armed with Schema.org JSON-LD microdata.',
    '[INFO] Click "Run Python Indexing Bot" to submit URLs directly to Googlebot.'
  ]);
  const [copiedScript, setCopiedScript] = useState(false);
  const [copiedSitemap, setCopiedSitemap] = useState(false);
  const [copiedShare, setCopiedShare] = useState(false);

  // Image Upload and Delete Dialog State
  const [imageUploadTab, setImageUploadTab] = useState<'upload' | 'url'>('upload');
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);

  // Affiliate tag update state
  const [newTagInput, setNewTagInput] = useState(adminSettings.affiliateTag);
  const [tagSuccessMsg, setTagSuccessMsg] = useState('');

  // Password change state
  const [newPassword, setNewPassword] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState('');

  React.useEffect(() => setNewTagInput(adminSettings.affiliateTag), [adminSettings.affiliateTag]);

  if (!isOpen) return null;

  // Handle password submission
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (await onAuthenticate(passwordInput)) {
      setAuthError('');
      setPasswordInput('');
    } else {
      setAuthError('Incorrect admin password.');
    }
  };

  // Metrics calculations
  const totalClicksCount = clicks.length;
  const potentialCommissionTotal = clicks.reduce((acc, curr) => acc + (curr.estimatedCommission || 0), 0);
  const conversionRate = adminSettings.estimatedConversionRate || 8.5;
  const estimatedActualPurchases = Math.round(totalClicksCount * (conversionRate / 100));
  const estimatedEarnedCommission = Number((potentialCommissionTotal * (conversionRate / 100)).toFixed(2));

  // Auto-generate Viral SEO data for the current editing product
  const handleAutoGenerateSeo = () => {
    const seo = generateViralSeoData(editingProduct);
    setEditingProduct(prev => ({
      ...prev,
      seoTitle: seo.seoTitle,
      seoDescription: seo.seoDescription,
      slug: seo.slug,
      seoKeywords: seo.seoKeywords,
      seoScore: 100,
    }));
  };

  // Run Python Google Indexing Bot
  const handleRunPythonBot = () => {
    setBotRunning(true);
    const startTime = new Date().toLocaleTimeString();
    setBotLogs([
      `[${startTime}] 🚀 Starting Python Google Indexing Bot v2.4 (PID: 5912)...`,
      `[${startTime}] [CONFIG] Host: https://amazonpartnerus.com`,
      `[${startTime}] [SITEMAP] Parsing dynamic sitemap.xml with ${products.length} product URLs...`,
    ]);

    setTimeout(() => {
      setBotLogs(prev => [
        ...prev,
        `[${new Date().toLocaleTimeString()}] [HTTP 200] Pinging Google Search Ping API: https://www.google.com/ping?sitemap=...`,
        `[${new Date().toLocaleTimeString()}] [GOOGLEBOT] Sitemap notification acknowledged by Googlebot cluster.`,
      ]);
    }, 900);

    setTimeout(() => {
      setBotLogs(prev => [
        ...prev,
        `[${new Date().toLocaleTimeString()}] [API v3] Submitting priority batch URLs to Google Indexing API...`,
        ...products.slice(0, 4).map(p => `  --> URL: /product/${p.slug || createSlug(p.title)} [PRIORITY 1.0 - STATUS: SUBMITTED]`),
      ]);
    }, 1800);

    setTimeout(() => {
      setBotLogs(prev => [
        ...prev,
        `[${new Date().toLocaleTimeString()}] [INDEXNOW] Broadcasting to Bing & Search Network API...`,
        `[${new Date().toLocaleTimeString()}] [RICH_SNIPPETS] Validating Schema.org Product microdata: 100% Valid (Price, USD, InStock, Stars).`,
        `[${new Date().toLocaleTimeString()}] 🎉 [COMPLETE] All product pages queued for rapid Google ranking!`,
      ]);
      setBotRunning(false);
    }, 2800);
  };

  // Download python bot script
  const handleDownloadPythonScript = () => {
    const code = generatePythonBotScript(products);
    const blob = new Blob([code], { type: 'text/x-python' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'google_indexer_bot.py';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Handle local image file upload (PNG, JPG, WebP)
  const handleImageFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      alert('Image file size must be under 5MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = async () => {
      if (typeof reader.result !== 'string') return;
      try {
        const { url } = await api.upload(reader.result);
        setEditingProduct(prev => ({ ...prev, imageUrl: url }));
      } catch (err) { alert('Upload failed: ' + (err as Error).message); }
    };
    reader.readAsDataURL(file);
  };

  // Handle open add product
  const handleOpenAddProduct = () => {
    const defaultProd: Partial<Product> = {
      id: 'prod-' + Date.now(),
      title: '',
      brand: '',
      category: 'Electronics & Tech',
      price: 99.99,
      originalPrice: 129.99,
      affiliateUrl: `https://www.amazon.com/dp/B08N5WRWNW?tag=${adminSettings.affiliateTag}`,
      asin: '',
      imageUrl: 'https://images.unsplash.com/photo-1526738549149-8e07eca6c147?auto=format&fit=crop&w=800&q=80',
      rating: 4.8,
      reviewCount: 1250,
      primeEligible: true,
      isBestSeller: false,
      isChoice: false,
      commissionRate: adminSettings.defaultCommissionRate || 4.0,
      description: 'High-performance US consumer essential with prime delivery and top-rated quality.',
      features: ['Premium construction', 'Compatible with US voltage / standards', 'Fast shipping with Amazon Prime'],
      inStock: true,
      clicksCount: 0,
      dateAdded: new Date().toISOString().split('T')[0],
      seoTitle: 'Top Rated Amazon Deal (2026) - Best Price on Amazon US',
      seoDescription: 'Check out this verified Amazon deal with fast Prime shipping and authentic buyer reviews.',
      slug: 'new-amazon-deal-' + Date.now().toString().slice(-4),
      seoKeywords: ['amazon deals 2026', 'best price amazon us', 'top rated product'],
      seoScore: 90,
      indexedStatus: 'Queued',
    };
    setEditingProduct(defaultProd);
    setIsEditingProduct(true);
  };

  const handleOpenEditProduct = (prod: Product) => {
    // If product doesn't have SEO fields, auto-populate them
    const seo = generateViralSeoData(prod);
    setEditingProduct({
      ...prod,
      seoTitle: prod.seoTitle || seo.seoTitle,
      seoDescription: prod.seoDescription || seo.seoDescription,
      slug: prod.slug || seo.slug,
      seoKeywords: prod.seoKeywords || seo.seoKeywords,
      seoScore: prod.seoScore || 100,
    });
    setIsEditingProduct(true);
  };

  const handleSaveProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct.title || !editingProduct.affiliateUrl) {
      alert('Product title and Amazon Affiliate URL are required!');
      return;
    }
    onSaveProduct(editingProduct as Product);
    setIsEditingProduct(false);
  };

  // Export clicks to CSV
  const handleExportCSV = () => {
    if (clicks.length === 0) {
      alert('No click events logged yet.');
      return;
    }
    const headers = ['Click ID', 'Timestamp', 'Product Title', 'Product Price ($)', 'Commission Rate (%)', 'Est Commission ($)', 'Affiliate Tag'];
    const rows = clicks.map(c => [
      c.id,
      c.timestamp,
      `"${c.productTitle.replace(/"/g, '""')}"`,
      c.productPrice,
      c.commissionRate,
      c.estimatedCommission,
      c.affiliateTag
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `amazon_affiliate_clicks_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Apply new affiliate tag
  const handleApplyAffiliateTag = () => {
    if (!newTagInput.trim()) return;
    onBulkUpdateAffiliateTag(newTagInput.trim());
    setTagSuccessMsg(`Updated all product affiliate links with tag: "${newTagInput.trim()}"`);
    setTimeout(() => setTagSuccessMsg(''), 4000);
  };

  // Change admin password
  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 4) {
      alert('Password must be at least 4 characters long.');
      return;
    }
    onSaveAdminSettings({
      ...adminSettings,
      adminPasswordHash: newPassword,
    });
    setNewPassword('');
    setPasswordSuccess('Admin password successfully updated!');
    setTimeout(() => setPasswordSuccess(''), 3000);
  };

  const filteredProducts = products.filter(p => 
    p.title.toLowerCase().includes(productSearch.toLowerCase()) ||
    p.brand.toLowerCase().includes(productSearch.toLowerCase()) ||
    p.asin.toLowerCase().includes(productSearch.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div 
        className="relative w-full max-w-5xl h-[90vh] bg-zinc-950 border border-zinc-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden text-zinc-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Bar */}
        <div className="px-6 py-4 bg-zinc-900 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-400">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Amazon Partner Store & Affiliate Control Center
                <span className="text-[10px] bg-zinc-800 text-amber-400 px-2 py-0.5 rounded border border-zinc-700">
                  Protected Portal
                </span>
              </h2>
              <p className="text-xs text-zinc-400">
                Manage Amazon affiliate hyperlinks, track commissions, and curate US store products
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {isAuthenticated && (
              <button
                onClick={onLogoutAdmin}
                className="text-xs px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-750 text-zinc-300 border border-zinc-700 transition-colors"
              >
                Lock Panel
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 text-zinc-400 hover:text-white rounded-lg bg-zinc-800 hover:bg-zinc-750 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Area */}
        {!isAuthenticated ? (
          /* Password Protection Screen */
          <div className="flex-1 flex items-center justify-center p-6">
            <form onSubmit={handleLogin} className="w-full max-w-md p-8 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-5 text-center shadow-2xl">
              <div className="w-14 h-14 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 mx-auto flex items-center justify-center">
                <Lock className="w-7 h-7" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Admin Authentication</h3>
                <p className="text-xs text-zinc-400 mt-1">
                  Enter password to access the store management and affiliate commission analytics.
                </p>
              </div>

              {authError && (
                <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2 text-left">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  <span>{authError}</span>
                </div>
              )}

              <div className="space-y-2 text-left">
                <label className="text-xs font-semibold text-zinc-300">Admin Password</label>
                <input
                  type="password"
                  placeholder="Enter admin password"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-lg px-3.5 py-2.5 text-sm text-zinc-100 placeholder:text-zinc-500 focus:outline-none focus:border-amber-500"
                  autoFocus
                />
                
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-sm transition-all shadow-md"
              >
                Unlock Admin Dashboard
              </button>
            </form>
          </div>
        ) : (
          /* Authenticated Dashboard */
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Tabs */}
            <div className="flex items-center gap-2 px-6 pt-3 border-b border-zinc-800 bg-zinc-900/50 text-xs">
              <button
                onClick={() => setActiveTab('overview')}
                className={`flex items-center gap-2 px-4 py-2.5 border-b-2 font-semibold transition-all ${
                  activeTab === 'overview'
                    ? 'border-amber-500 text-amber-400 bg-zinc-850/50'
                    : 'border-transparent text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <TrendingUp className="w-4 h-4" /> Affiliate Analytics & Commissions
              </button>
              <button
                onClick={() => setActiveTab('products')}
                className={`flex items-center gap-2 px-4 py-2.5 border-b-2 font-semibold transition-all ${
                  activeTab === 'products'
                    ? 'border-amber-500 text-amber-400 bg-zinc-850/50'
                    : 'border-transparent text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <Package className="w-4 h-4" /> Product & Buy Links ({products.length})
              </button>
              <button
                onClick={() => setActiveTab('seo-bot')}
                className={`flex items-center gap-2 px-4 py-2.5 border-b-2 font-semibold transition-all ${
                  activeTab === 'seo-bot'
                    ? 'border-amber-500 text-amber-400 bg-zinc-850/50'
                    : 'border-transparent text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <Cpu className="w-4 h-4 text-emerald-400" /> Google SEO & Python Bot
              </button>
              <button
                onClick={() => setActiveTab('clicks')}
                className={`flex items-center gap-2 px-4 py-2.5 border-b-2 font-semibold transition-all ${
                  activeTab === 'clicks'
                    ? 'border-amber-500 text-amber-400 bg-zinc-850/50'
                    : 'border-transparent text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <MousePointerClick className="w-4 h-4" /> Click Log ({clicks.length})
              </button>
              <button
                onClick={() => setActiveTab('settings')}
                className={`flex items-center gap-2 px-4 py-2.5 border-b-2 font-semibold transition-all ${
                  activeTab === 'settings'
                    ? 'border-amber-500 text-amber-400 bg-zinc-850/50'
                    : 'border-transparent text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <Settings className="w-4 h-4" /> Affiliate & Security Settings
              </button>
            </div>

            {/* Tab Contents */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* TAB 1: OVERVIEW & COMMISSIONS */}
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  {/* KPI Cards */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800">
                      <div className="flex items-center justify-between text-zinc-400 text-xs mb-1">
                        <span>Total Affiliate Clicks</span>
                        <MousePointerClick className="w-4 h-4 text-amber-400" />
                      </div>
                      <div className="text-2xl font-black text-white">{totalClicksCount}</div>
                      <p className="text-[11px] text-zinc-500 mt-1">Outbound visits to Amazon US</p>
                    </div>

                    <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800">
                      <div className="flex items-center justify-between text-zinc-400 text-xs mb-1">
                        <span>Est. Commission Earned</span>
                        <DollarSign className="w-4 h-4 text-emerald-400" />
                      </div>
                      <div className="text-2xl font-black text-emerald-400">
                        ${estimatedEarnedCommission.toFixed(2)}
                      </div>
                      <p className="text-[11px] text-zinc-500 mt-1">Based on {conversionRate}% conversion rate</p>
                    </div>

                    <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800">
                      <div className="flex items-center justify-between text-zinc-400 text-xs mb-1">
                        <span>Gross Order Value Tracked</span>
                        <TrendingUp className="w-4 h-4 text-sky-400" />
                      </div>
                      <div className="text-2xl font-black text-white">
                        ${clicks.reduce((acc, c) => acc + c.productPrice, 0).toFixed(2)}
                      </div>
                      <p className="text-[11px] text-zinc-500 mt-1">Total retail cart intent</p>
                    </div>

                    <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800">
                      <div className="flex items-center justify-between text-zinc-400 text-xs mb-1">
                        <span>Active Tag</span>
                        <LinkIcon className="w-4 h-4 text-amber-400" />
                      </div>
                      <div className="text-lg font-mono font-bold text-amber-400 truncate">
                        {adminSettings.affiliateTag}
                      </div>
                      <p className="text-[11px] text-zinc-500 mt-1">Amazon Associates ID</p>
                    </div>
                  </div>

                  {/* Commission calculation formula breakdown */}
                  <div className="p-4 rounded-xl bg-zinc-900/60 border border-zinc-800 text-xs space-y-2">
                    <h4 className="font-bold text-zinc-200 flex items-center gap-2">
                      <DollarSign className="w-4 h-4 text-amber-400" />
                      How Your Amazon Commission Is Calculated
                    </h4>
                    <p className="text-zinc-400 leading-relaxed">
                      Amazon Associates pays standard variable commission rates (typically 2.5% to 5.0% for Consumer Electronics & Home). 
                      When an American customer clicks your "Buy on Amazon" hyperlink, Amazon’s 24-hour cookie tracks any purchases they complete in their cart.
                    </p>
                    <div className="flex flex-wrap items-center gap-4 pt-2 text-[11px] text-zinc-300 font-mono">
                      <span className="bg-zinc-800 px-2.5 py-1 rounded">Gross Cart Clicks: {totalClicksCount}</span>
                      <span>×</span>
                      <span className="bg-zinc-800 px-2.5 py-1 rounded">Avg Conv: {conversionRate}%</span>
                      <span>=</span>
                      <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2.5 py-1 rounded">
                        Est. Orders: ~{estimatedActualPurchases}
                      </span>
                    </div>
                  </div>

                  {/* Top Clicked Products */}
                  <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-sm font-bold text-white">Top Performing Products by Clicks</h4>
                      <button
                        onClick={() => setActiveTab('products')}
                        className="text-xs text-amber-400 hover:underline flex items-center gap-1"
                      >
                        Manage Links <ArrowUpRight className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="space-y-3">
                      {products
                        .slice()
                        .sort((a, b) => (b.clicksCount || 0) - (a.clicksCount || 0))
                        .slice(0, 5)
                        .map((prod, idx) => (
                          <div key={prod.id} className="flex items-center justify-between p-3 rounded-lg bg-zinc-950/60 border border-zinc-850 text-xs">
                            <div className="flex items-center gap-3">
                              <span className="font-mono text-zinc-500 w-4 font-bold">#{idx + 1}</span>
                              <img src={prod.imageUrl} alt={prod.title} className="w-9 h-9 rounded object-cover border border-zinc-800" />
                              <div className="max-w-md">
                                <p className="font-medium text-zinc-200 truncate">{prod.title}</p>
                                <p className="text-[11px] text-zinc-500">{prod.brand} • ${prod.price.toFixed(2)}</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-4">
                              <div className="text-right">
                                <span className="font-bold text-zinc-100">{prod.clicksCount || 0}</span>
                                <span className="text-zinc-500 text-[10px] block">clicks</span>
                              </div>
                              <span className="text-emerald-400 font-mono font-semibold">
                                {prod.commissionRate}% comm.
                              </span>
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: PRODUCTS MANAGER & HYPERLINK EDITOR */}
              {activeTab === 'products' && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
                    <div className="relative w-full sm:w-72">
                      <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-2.5" />
                      <input
                        type="text"
                        placeholder="Filter by title, brand, or ASIN..."
                        value={productSearch}
                        onChange={(e) => setProductSearch(e.target.value)}
                        className="w-full bg-zinc-900 border border-zinc-800 text-xs text-zinc-100 pl-9 pr-3 py-2 rounded-lg focus:outline-none focus:border-amber-500"
                      />
                    </div>

                    <button
                      onClick={handleOpenAddProduct}
                      className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs transition-all shadow-md"
                    >
                      <Plus className="w-4 h-4" /> Add New Amazon Product
                    </button>
                  </div>

                  {/* Products Table */}
                  <div className="border border-zinc-800 rounded-xl overflow-hidden bg-zinc-900">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-zinc-850/80 text-zinc-400 uppercase tracking-wider text-[10px] border-b border-zinc-800">
                          <tr>
                            <th className="py-3 px-4">Product Details</th>
                            <th className="py-3 px-4">Price / Rate</th>
                            <th className="py-3 px-4">Amazon Affiliate Hyperlink</th>
                            <th className="py-3 px-4 text-center">Clicks</th>
                            <th className="py-3 px-4 text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-zinc-800/80">
                          {filteredProducts.map((p) => (
                            <tr key={p.id} className="hover:bg-zinc-850/40 transition-colors">
                              <td className="py-3 px-4">
                                <div className="flex items-center gap-3">
                                  <img src={p.imageUrl} alt={p.title} className="w-10 h-10 rounded object-cover border border-zinc-800 flex-shrink-0" />
                                  <div className="max-w-xs sm:max-w-sm">
                                    <p className="font-semibold text-zinc-100 truncate" title={p.title}>{p.title}</p>
                                    <div className="flex items-center gap-2 text-[10px] text-zinc-400 mt-0.5">
                                      <span className="text-amber-400">{p.brand}</span>
                                      <span>•</span>
                                      <span>ASIN: {p.asin}</span>
                                      {p.primeEligible && <span className="text-sky-400 font-semibold">• Prime</span>}
                                    </div>
                                  </div>
                                </div>
                              </td>

                              <td className="py-3 px-4">
                                <div className="font-bold text-zinc-100">${p.price.toFixed(2)}</div>
                                <span className="text-[10px] text-emerald-400 font-mono">{p.commissionRate}% comm.</span>
                              </td>

                              <td className="py-3 px-4 max-w-xs">
                                <a
                                  href={p.affiliateUrl}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-amber-400 hover:underline flex items-center gap-1 font-mono text-[11px] truncate"
                                  title={p.affiliateUrl}
                                >
                                  <span className="truncate">{p.affiliateUrl}</span>
                                  <ExternalLink className="w-3 h-3 flex-shrink-0" />
                                </a>
                              </td>

                              <td className="py-3 px-4 text-center font-bold font-mono text-zinc-200">
                                {p.clicksCount || 0}
                              </td>

                              <td className="py-3 px-4 text-right">
                                <div className="flex items-center justify-end gap-2">
                                  <button
                                    onClick={() => handleOpenEditProduct(p)}
                                    className="p-1.5 rounded hover:bg-zinc-800 text-zinc-300 hover:text-amber-400 transition-colors"
                                    title="Edit Product and Affiliate Link"
                                  >
                                    <Edit3 className="w-4 h-4" />
                                  </button>
                                  <button
                                    onClick={() => setProductToDelete(p)}
                                    className="p-1.5 rounded hover:bg-rose-500/10 text-zinc-400 hover:text-rose-400 transition-colors"
                                    title="Delete Product"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB: GOOGLE SEO & PYTHON INDEXER BOT */}
              {activeTab === 'seo-bot' && (
                <div className="space-y-6">
                  {/* Top Status Cards */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800">
                      <div className="flex items-center justify-between text-zinc-400 text-xs mb-1">
                        <span>URLs Armed For Indexing</span>
                        <Globe className="w-4 h-4 text-emerald-400" />
                      </div>
                      <div className="text-2xl font-black text-white">{products.length} Products</div>
                      <p className="text-[11px] text-emerald-400 mt-1 flex items-center gap-1">
                        <Check className="w-3 h-3" /> Ready in dynamic sitemap.xml
                      </p>
                    </div>

                    <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800">
                      <div className="flex items-center justify-between text-zinc-400 text-xs mb-1">
                        <span>Googlebot Crawl Speed</span>
                        <Cpu className="w-4 h-4 text-amber-400" />
                      </div>
                      <div className="text-2xl font-black text-amber-400">Priority 1.0</div>
                      <p className="text-[11px] text-zinc-500 mt-1">Direct Google Search Console ping</p>
                    </div>

                    <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800">
                      <div className="flex items-center justify-between text-zinc-400 text-xs mb-1">
                        <span>Google Rich Snippets</span>
                        <Sparkles className="w-4 h-4 text-sky-400" />
                      </div>
                      <div className="text-2xl font-black text-sky-400">Schema.org</div>
                      <p className="text-[11px] text-zinc-500 mt-1">Stars, Price ($), In-Stock enabled</p>
                    </div>

                    <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800">
                      <div className="flex items-center justify-between text-zinc-400 text-xs mb-1">
                        <span>Search Engine Target</span>
                        <Flame className="w-4 h-4 text-rose-400" />
                      </div>
                      <div className="text-lg font-bold text-white">Google US (Top 1)</div>
                      <p className="text-[11px] text-zinc-500 mt-1">Targeting high-intent buyers</p>
                    </div>
                  </div>

                  {/* Bot Controls & Live Terminal Console */}
                  <div className="p-5 rounded-xl bg-zinc-900 border border-zinc-800 space-y-4">
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                      <div>
                        <h4 className="text-sm font-bold text-white flex items-center gap-2">
                          <Terminal className="w-4 h-4 text-emerald-400" />
                          Python Google Indexer Bot Console
                        </h4>
                        <p className="text-xs text-zinc-400">
                          Automates instant Google Search Console pinging and IndexNow submission to rank products on top of Google search.
                        </p>
                      </div>

                      <div className="flex flex-wrap items-center gap-2">
                        <button
                          onClick={handleRunPythonBot}
                          disabled={botRunning}
                          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 active:scale-[0.99] text-zinc-950 font-bold text-xs transition-all shadow-md shadow-emerald-500/20 disabled:opacity-60"
                        >
                          <Play className={`w-3.5 h-3.5 ${botRunning ? 'animate-spin' : ''}`} />
                          {botRunning ? 'Pinging Googlebot...' : 'Run Python Indexing Bot Now'}
                        </button>

                        <button
                          onClick={handleDownloadPythonScript}
                          className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-zinc-800 hover:bg-zinc-750 text-zinc-200 border border-zinc-700 text-xs font-semibold transition-all"
                          title="Download google_indexer_bot.py"
                        >
                          <Download className="w-3.5 h-3.5" /> Download .py Script
                        </button>

                        <button
                          onClick={() => {
                            navigator.clipboard.writeText(generatePythonBotScript(products));
                            setCopiedScript(true);
                            setTimeout(() => setCopiedScript(false), 2000);
                          }}
                          className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-zinc-800 hover:bg-zinc-750 text-zinc-200 border border-zinc-700 text-xs font-semibold transition-all"
                        >
                          {copiedScript ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                              <span className="text-emerald-400">Copied!</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              <span>Copy Bot Code</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>

                    {/* Interactive CLI Terminal Display */}
                    <div className="rounded-xl bg-black border border-zinc-800 overflow-hidden shadow-2xl">
                      <div className="px-4 py-2 bg-zinc-900/90 border-b border-zinc-800 flex items-center justify-between text-xs text-zinc-400">
                        <div className="flex items-center gap-2 font-mono text-[11px]">
                          <span className="w-3 h-3 rounded-full bg-rose-500/80 inline-block" />
                          <span className="w-3 h-3 rounded-full bg-amber-500/80 inline-block" />
                          <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block" />
                          <span className="ml-2 text-zinc-300">python3 google_indexer_bot.py --mode auto</span>
                        </div>
                        <span className="text-[10px] text-zinc-500">Live Bot Terminal</span>
                      </div>

                      <div className="p-4 font-mono text-xs text-zinc-300 space-y-1.5 max-h-64 overflow-y-auto no-scrollbar">
                        {botLogs.map((log, index) => {
                          const isSuccess = log.includes('[SUCCESS]') || log.includes('🎉') || log.includes('[COMPLETE]');
                          const isOk = log.includes('[HTTP 200]') || log.includes('[OK]') || log.includes('[PRIORITY 1.0');
                          const isInit = log.includes('🚀') || log.includes('[INIT]');
                          return (
                            <div
                              key={index}
                              className={`leading-relaxed ${
                                isSuccess
                                  ? 'text-emerald-400 font-semibold'
                                  : isOk
                                  ? 'text-sky-400'
                                  : isInit
                                  ? 'text-amber-400 font-bold'
                                  : 'text-zinc-300'
                              }`}
                            >
                              {log}
                            </div>
                          );
                        })}
                        {botRunning && (
                          <div className="flex items-center gap-2 text-amber-400 animate-pulse text-[11px]">
                            <span>▶ Transmitting ping packets to Googlebot endpoints...</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Sitemap & Viral Backlinks Section */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Dynamic Sitemap.xml */}
                    <div className="p-5 rounded-xl bg-zinc-900 border border-zinc-800 space-y-3">
                      <div className="flex items-center justify-between">
                        <h4 className="text-sm font-bold text-white flex items-center gap-2">
                          <Globe className="w-4 h-4 text-sky-400" />
                          Dynamic Google Sitemap XML
                        </h4>
                        <button
                          onClick={() => {
                            navigator.clipboard.writeText(generateSitemapXml(products));
                            setCopiedSitemap(true);
                            setTimeout(() => setCopiedSitemap(false), 2000);
                          }}
                          className="text-xs text-amber-400 hover:underline flex items-center gap-1"
                        >
                          {copiedSitemap ? 'Copied XML!' : 'Copy sitemap.xml'}
                        </button>
                      </div>
                      <p className="text-xs text-zinc-400">
                        Generated automatically for Googlebot crawler discovery. Every product has priority 0.9 with daily refresh.
                      </p>
                      <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800 font-mono text-[11px] text-zinc-400 max-h-36 overflow-y-auto">
                        <pre>{generateSitemapXml(products).slice(0, 450)}... [+{products.length} URLs]</pre>
                      </div>
                    </div>

                    {/* Viral Social Signals & Backlinks */}
                    <div className="p-5 rounded-xl bg-zinc-900 border border-zinc-800 space-y-3">
                      <div className="flex items-center justify-between">
                        <h4 className="text-sm font-bold text-white flex items-center gap-2">
                          <Share2 className="w-4 h-4 text-rose-400" />
                          Viral Social Blast & Backlink Signals
                        </h4>
                        <button
                          onClick={() => {
                            const p = products[0];
                            const text = `🔥 Huge US Amazon Deal: ${p?.title} is now only $${p?.price.toFixed(2)} with Prime 2-Day Shipping!\\n\\nCheck live price & reviews: https://amazonpartnerus.com/product/${p?.slug}\\n\\n#AmazonDeals #AmazonPrime #TechDeals #USShopping #BestPrice`;
                            navigator.clipboard.writeText(text);
                            setCopiedShare(true);
                            setTimeout(() => setCopiedShare(false), 2000);
                          }}
                          className="text-xs text-amber-400 hover:underline flex items-center gap-1"
                        >
                          {copiedShare ? 'Copied Post!' : 'Copy Viral Post'}
                        </button>
                      </div>
                      <p className="text-xs text-zinc-400">
                        Posting to Twitter/X, Reddit, or Pinterest creates instant external backlinks, signaling Google to crawl and index your page faster.
                      </p>
                      <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800 text-xs text-zinc-300 space-y-2">
                        <p className="font-semibold text-white">
                          🔥 Huge US Amazon Deal: {products[0]?.title} is now only ${products[0]?.price.toFixed(2)} with Prime 2-Day Shipping!
                        </p>
                        <p className="text-[11px] text-amber-400 font-mono">
                          Check verified price: https://amazonpartnerus.com/product/{products[0]?.slug}
                        </p>
                        <p className="text-[11px] text-zinc-500">
                          #AmazonDeals #AmazonPrime #TechDeals #USShopping #SaveMoney
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: CLICK LOG */}
              {activeTab === 'clicks' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-bold text-white">Live Affiliate Redirection Logs</h4>
                      <p className="text-xs text-zinc-400">
                        Tracks every time a visitor clicks "Buy on Amazon" with your affiliate referral parameter.
                      </p>
                    </div>

                    <button
                      onClick={handleExportCSV}
                      disabled={clicks.length === 0}
                      className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-750 text-zinc-200 border border-zinc-700 text-xs font-semibold disabled:opacity-50 transition-all"
                    >
                      <Download className="w-3.5 h-3.5" /> Export to CSV
                    </button>
                  </div>

                  {clicks.length === 0 ? (
                    <div className="text-center py-12 border border-zinc-800 rounded-xl bg-zinc-900/50">
                      <MousePointerClick className="w-8 h-8 text-zinc-600 mx-auto mb-2" />
                      <p className="text-xs text-zinc-400">No clicks recorded yet.</p>
                      <p className="text-[11px] text-zinc-500 mt-1">
                        When users click "Buy on Amazon" buttons on the store, events will display here in real time.
                      </p>
                    </div>
                  ) : (
                    <div className="border border-zinc-800 rounded-xl overflow-hidden bg-zinc-900">
                      <div className="max-h-96 overflow-y-auto">
                        <table className="w-full text-left text-xs">
                          <thead className="bg-zinc-850/80 text-zinc-400 uppercase tracking-wider text-[10px] border-b border-zinc-800 sticky top-0">
                            <tr>
                              <th className="py-2.5 px-4">Timestamp</th>
                              <th className="py-2.5 px-4">Product</th>
                              <th className="py-2.5 px-4">Retail Price</th>
                              <th className="py-2.5 px-4">Est Commission</th>
                              <th className="py-2.5 px-4">Tag</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-zinc-800/80 font-mono text-[11px]">
                            {clicks.map((clk) => (
                              <tr key={clk.id} className="hover:bg-zinc-850/40">
                                <td className="py-2.5 px-4 text-zinc-400">
                                  {new Date(clk.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                                  <span className="text-[10px] text-zinc-600 block">{new Date(clk.timestamp).toLocaleDateString()}</span>
                                </td>
                                <td className="py-2.5 px-4 font-sans font-medium text-zinc-200 max-w-xs truncate">
                                  {clk.productTitle}
                                </td>
                                <td className="py-2.5 px-4 text-zinc-100">
                                  ${clk.productPrice.toFixed(2)}
                                </td>
                                <td className="py-2.5 px-4 text-emerald-400 font-bold">
                                  ${clk.estimatedCommission.toFixed(2)} ({clk.commissionRate}%)
                                </td>
                                <td className="py-2.5 px-4 text-amber-400">
                                  {clk.affiliateTag}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* TAB 4: SETTINGS & BULK TAG UPDATER */}
              {activeTab === 'settings' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Amazon Associates Tag Configuration */}
                  <div className="p-5 rounded-xl bg-zinc-900 border border-zinc-800 space-y-4">
                    <h4 className="text-sm font-bold text-white flex items-center gap-2">
                      <LinkIcon className="w-4 h-4 text-amber-400" />
                      Amazon Associates Tag Configuration
                    </h4>
                    <p className="text-xs text-zinc-400">
                      Change your affiliate ID here (e.g. <code className="text-amber-400">yourtag-20</code>). 
                      Clicking apply will automatically update all existing products with your tag!
                    </p>

                    <div className="space-y-2">
                      <label className="text-xs font-semibold text-zinc-300">Your Amazon Tracking Tag</label>
                      <input
                        type="text"
                        value={newTagInput}
                        onChange={(e) => setNewTagInput(e.target.value)}
                        placeholder="e.g. apexdeals-20"
                        className="w-full bg-zinc-950 border border-zinc-700 rounded-lg px-3 py-2 text-xs font-mono text-amber-400 focus:outline-none focus:border-amber-500"
                      />
                    </div>

                    {tagSuccessMsg && (
                      <p className="text-xs text-emerald-400 flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5" /> {tagSuccessMsg}
                      </p>
                    )}

                    <button
                      onClick={handleApplyAffiliateTag}
                      className="w-full py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs transition-all shadow-md"
                    >
                      Update Tag Across All Products
                    </button>
                  </div>

                  {/* Change Admin Password */}
                  <div className="p-5 rounded-xl bg-zinc-900 border border-zinc-800 space-y-4">
                    <h4 className="text-sm font-bold text-white flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-emerald-400" />
                      Admin Security & Password
                    </h4>
                    <p className="text-xs text-zinc-400">
                      Update the master password that protects this administration panel.
                    </p>

                    <form onSubmit={handleChangePassword} className="space-y-3">
                      <div>
                        <label className="text-xs font-semibold text-zinc-300">New Password</label>
                        <input
                          type="password"
                          value={newPassword}
                          onChange={(e) => setNewPassword(e.target.value)}
                          placeholder="Enter new admin password"
                          className="w-full bg-zinc-950 border border-zinc-700 rounded-lg px-3 py-2 text-xs text-zinc-100 focus:outline-none focus:border-amber-500"
                        />
                      </div>

                      {passwordSuccess && (
                        <p className="text-xs text-emerald-400 flex items-center gap-1.5">
                          <Check className="w-3.5 h-3.5" /> {passwordSuccess}
                        </p>
                      )}

                      <button
                        type="submit"
                        className="w-full py-2 rounded-lg bg-zinc-800 hover:bg-zinc-750 text-zinc-100 font-semibold text-xs border border-zinc-700 transition-all"
                      >
                        Save New Password
                      </button>
                    </form>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Product Add / Edit Modal Overlay */}
        {isEditingProduct && (
          <div className="absolute inset-0 z-50 bg-black/90 backdrop-blur-md p-6 flex items-center justify-center animate-in fade-in">
            <div className="w-full max-w-2xl max-h-[85vh] bg-zinc-950 border border-zinc-800 rounded-2xl p-6 overflow-y-auto space-y-4 shadow-2xl">
              <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
                <h3 className="text-base font-bold text-white">
                  {editingProduct.id?.startsWith('prod-') && products.some(p => p.id === editingProduct.id)
                    ? 'Edit Amazon Product & Hyperlink'
                    : 'Add New Amazon Product'}
                </h3>
                <button
                  onClick={() => setIsEditingProduct(false)}
                  className="p-1 rounded text-zinc-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveProductSubmit} className="space-y-4 text-xs">
                {/* Title */}
                <div>
                  <label className="font-semibold text-zinc-300 block mb-1">Product Title</label>
                  <input
                    type="text"
                    required
                    value={editingProduct.title || ''}
                    onChange={(e) => setEditingProduct({ ...editingProduct, title: e.target.value })}
                    placeholder="e.g. Sony WH-1000XM5 Wireless Headphones"
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-2 text-zinc-100 focus:outline-none focus:border-amber-500"
                  />
                </div>

                {/* Affiliate Hyperlink (The core request) */}
                <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/30">
                  <label className="font-bold text-amber-300 block mb-1 flex items-center gap-1.5">
                    <LinkIcon className="w-3.5 h-3.5" />
                    Amazon Buy Now Hyperlink (Affiliate URL) *
                  </label>
                  <input
                    type="url"
                    required
                    value={editingProduct.affiliateUrl || ''}
                    onChange={(e) => setEditingProduct({ ...editingProduct, affiliateUrl: e.target.value })}
                    placeholder="https://www.amazon.com/dp/B09XS7JWHH?tag=yourtag-20"
                    className="w-full bg-zinc-950 border border-zinc-700 rounded-lg px-3 py-2 font-mono text-amber-400 focus:outline-none focus:border-amber-500"
                  />
                  <p className="text-[10px] text-zinc-400 mt-1">
                    This is the destination link opened when US shoppers click "Buy on Amazon". Ensure your tag is included.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="font-semibold text-zinc-300 block mb-1">Brand</label>
                    <input
                      type="text"
                      required
                      value={editingProduct.brand || ''}
                      onChange={(e) => setEditingProduct({ ...editingProduct, brand: e.target.value })}
                      placeholder="e.g. Sony, Apple, Breville"
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-2 text-zinc-100 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                  <div>
                    <label className="font-semibold text-zinc-300 block mb-1">Category</label>
                    <select
                      value={editingProduct.category || 'Electronics & Tech'}
                      onChange={(e) => setEditingProduct({ ...editingProduct, category: e.target.value })}
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-2 text-zinc-100 focus:outline-none focus:border-amber-500"
                    >
                      <option value="Electronics & Tech">Electronics & Tech</option>
                      <option value="Smart Home & Audio">Smart Home & Audio</option>
                      <option value="Kitchen & Appliances">Kitchen & Appliances</option>
                      <option value="Health & Fitness">Health & Fitness</option>
                      <option value="Workstation & Office">Workstation & Office</option>
                      <option value="Gaming Gear">Gaming Gear</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="font-semibold text-zinc-300 block mb-1">Price (USD $)</label>
                    <input
                      type="number"
                      step="0.01"
                      required
                      value={editingProduct.price || 0}
                      onChange={(e) => setEditingProduct({ ...editingProduct, price: parseFloat(e.target.value) || 0 })}
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-2 text-zinc-100 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                  <div>
                    <label className="font-semibold text-zinc-300 block mb-1">Original List Price ($)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={editingProduct.originalPrice || 0}
                      onChange={(e) => setEditingProduct({ ...editingProduct, originalPrice: parseFloat(e.target.value) || 0 })}
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-2 text-zinc-100 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                  <div>
                    <label className="font-semibold text-zinc-300 block mb-1">Commission Rate (%)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={editingProduct.commissionRate || 4.0}
                      onChange={(e) => setEditingProduct({ ...editingProduct, commissionRate: parseFloat(e.target.value) || 4.0 })}
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-2 text-zinc-100 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="font-semibold text-zinc-300 block mb-1">ASIN</label>
                      <input
                        type="text"
                        value={editingProduct.asin || ''}
                        onChange={(e) => setEditingProduct({ ...editingProduct, asin: e.target.value })}
                        placeholder="e.g. B09XS7JWHH"
                        className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-2 font-mono text-zinc-100 focus:outline-none focus:border-amber-500"
                      />
                    </div>

                    {/* Image source tabs */}
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="font-semibold text-zinc-300">Product Image Source *</label>
                        <div className="flex gap-1 text-[10px]">
                          <button
                            type="button"
                            onClick={() => setImageUploadTab('upload')}
                            className={`px-2 py-0.5 rounded font-medium ${
                              imageUploadTab === 'upload' 
                                ? 'bg-amber-500 text-zinc-950 font-bold' 
                                : 'bg-zinc-800 text-zinc-400'
                            }`}
                          >
                            Upload File
                          </button>
                          <button
                            type="button"
                            onClick={() => setImageUploadTab('url')}
                            className={`px-2 py-0.5 rounded font-medium ${
                              imageUploadTab === 'url' 
                                ? 'bg-amber-500 text-zinc-950 font-bold' 
                                : 'bg-zinc-800 text-zinc-400'
                            }`}
                          >
                            Web URL
                          </button>
                        </div>
                      </div>

                      {imageUploadTab === 'upload' ? (
                        <div>
                          <label className="flex flex-col items-center justify-center p-3 border-2 border-dashed border-zinc-700 hover:border-amber-500/60 rounded-xl cursor-pointer bg-zinc-900/60 hover:bg-zinc-900 transition-all">
                            <Upload className="w-5 h-5 text-amber-400 mb-1" />
                            <span className="text-[11px] font-semibold text-zinc-200">
                              Choose Image from Device
                            </span>
                            <span className="text-[10px] text-zinc-500">
                              JPG, PNG, WebP up to 5MB
                            </span>
                            <input
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={handleImageFileUpload}
                            />
                          </label>
                        </div>
                      ) : (
                        <input
                          type="url"
                          value={editingProduct.imageUrl || ''}
                          onChange={(e) => setEditingProduct({ ...editingProduct, imageUrl: e.target.value })}
                          placeholder="https://images.unsplash.com/..."
                          className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-2 text-zinc-100 focus:outline-none focus:border-amber-500"
                        />
                      )}
                    </div>
                  </div>

                  {/* Image Live Preview */}
                  {editingProduct.imageUrl && (
                    <div className="flex items-center gap-3 p-2.5 rounded-xl bg-zinc-900/90 border border-zinc-800">
                      <img
                        src={editingProduct.imageUrl}
                        alt="Product Preview"
                        className="w-14 h-14 rounded-lg object-cover border border-zinc-700 flex-shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-semibold text-zinc-200">Product Image Preview</p>
                        <p className="text-[10px] text-zinc-500 truncate">{editingProduct.imageUrl.slice(0, 50)}...</p>
                        <p className="text-[10px] text-emerald-400 font-medium">✓ Image loaded & ready</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => setEditingProduct({ ...editingProduct, imageUrl: '' })}
                        className="text-xs text-rose-400 hover:text-rose-300 px-2 py-1 rounded bg-rose-500/10 hover:bg-rose-500/20 transition-colors"
                      >
                        Remove
                      </button>
                    </div>
                  )}
                </div>

                {/* Badges Toggles */}
                <div className="flex items-center gap-6 p-3 rounded-lg bg-zinc-900 border border-zinc-800">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingProduct.primeEligible ?? true}
                      onChange={(e) => setEditingProduct({ ...editingProduct, primeEligible: e.target.checked })}
                      className="rounded accent-amber-500"
                    />
                    <span className="font-medium text-zinc-200">Prime Eligible</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingProduct.isBestSeller ?? false}
                      onChange={(e) => setEditingProduct({ ...editingProduct, isBestSeller: e.target.checked })}
                      className="rounded accent-amber-500"
                    />
                    <span className="font-medium text-zinc-200">#1 Best Seller Badge</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingProduct.isChoice ?? false}
                      onChange={(e) => setEditingProduct({ ...editingProduct, isChoice: e.target.checked })}
                      className="rounded accent-amber-500"
                    />
                    <span className="font-medium text-zinc-200">Amazon's Choice</span>
                  </label>
                </div>

                {/* Description */}
                <div>
                  <label className="font-semibold text-zinc-300 block mb-1">Product Description</label>
                  <textarea
                    rows={3}
                    value={editingProduct.description || ''}
                    onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-2 text-zinc-100 focus:outline-none focus:border-amber-500"
                  />
                </div>

                {/* ADVANCED GOOGLE VIRAL SEO & SERP SNIPPET PREVIEW SECTION */}
                <div className="p-4 rounded-xl bg-zinc-900 border border-emerald-500/30 space-y-4 shadow-lg">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-2 border-b border-zinc-800">
                    <div>
                      <h4 className="text-sm font-bold text-white flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-emerald-400" />
                        Google Viral SEO & Top Search Ranking Strategy
                      </h4>
                      <p className="text-[11px] text-zinc-400">
                        Optimizes this post to rank on Google Search results with rich star snippets and buyer intent keywords.
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={handleAutoGenerateSeo}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold text-xs transition-all shadow-sm flex-shrink-0"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      Auto-Generate Viral SEO
                    </button>
                  </div>

                  {/* Live Google SERP Snippet Preview */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400">
                        Live Google Search Result Preview (#1 Position)
                      </span>
                      <div className="flex items-center gap-1 bg-zinc-950 p-0.5 rounded border border-zinc-800 text-[10px]">
                        <button
                          type="button"
                          onClick={() => setSerpDevice('desktop')}
                          className={`px-2 py-0.5 rounded flex items-center gap-1 ${
                            serpDevice === 'desktop' ? 'bg-zinc-800 text-white' : 'text-zinc-500'
                          }`}
                        >
                          <Monitor className="w-3 h-3" /> Desktop
                        </button>
                        <button
                          type="button"
                          onClick={() => setSerpDevice('mobile')}
                          className={`px-2 py-0.5 rounded flex items-center gap-1 ${
                            serpDevice === 'mobile' ? 'bg-zinc-800 text-white' : 'text-zinc-500'
                          }`}
                        >
                          <Smartphone className="w-3 h-3" /> Mobile
                        </button>
                      </div>
                    </div>

                    {/* Google SERP Box */}
                    <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-1.5 font-sans">
                      {/* URL breadcrumb */}
                      <div className="flex items-center gap-2 text-[12px] text-zinc-400">
                        <span className="w-4 h-4 rounded-full bg-amber-500/20 text-amber-400 font-bold text-[9px] flex items-center justify-center">
                          A
                        </span>
                        <div className="flex items-center gap-1 text-zinc-400">
                          <span className="text-zinc-200">https://amazonpartnerus.com</span>
                          <span>›</span>
                          <span>deals</span>
                          <span>›</span>
                          <span className="text-zinc-400 truncate max-w-[150px]">
                            {editingProduct.slug || 'product-deal'}
                          </span>
                        </div>
                      </div>

                      {/* Clickable blue title */}
                      <h4 className="text-[16px] font-medium text-sky-400 hover:underline cursor-pointer leading-tight">
                        {editingProduct.seoTitle || editingProduct.title || 'Product Title on Google Search'}
                      </h4>

                      {/* Rich snippets (Stars, Reviews, Price, In stock) */}
                      <div className="flex items-center gap-2 text-[12px] text-zinc-400 pt-0.5">
                        <div className="flex items-center text-amber-400 text-xs">
                          ★★★★★
                        </div>
                        <span className="font-bold text-zinc-200">{editingProduct.rating || 4.8}</span>
                        <span>·</span>
                        <span>{(editingProduct.reviewCount || 1200).toLocaleString()} votes</span>
                        <span>·</span>
                        <span className="text-zinc-200 font-semibold">${(editingProduct.price || 99).toFixed(2)}</span>
                        <span>·</span>
                        <span className="text-emerald-400 font-medium">In stock</span>
                      </div>

                      {/* Snippet Meta description */}
                      <p className="text-[13px] text-zinc-400 leading-snug pt-0.5">
                        {editingProduct.seoDescription || editingProduct.description || 'Verified US Amazon price check and customer review summary with Prime 2-day delivery.'}
                      </p>
                    </div>
                  </div>

                  {/* SEO Form Inputs */}
                  <div className="space-y-3 pt-2">
                    {/* SEO Title Input */}
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="font-semibold text-zinc-300">
                          Google Search SEO Title (Click-Magnet Title)
                        </label>
                        <span className={`text-[10px] font-mono ${
                          (editingProduct.seoTitle || '').length > 65 ? 'text-rose-400' : 'text-emerald-400'
                        }`}>
                          {(editingProduct.seoTitle || '').length} / 65 chars
                        </span>
                      </div>
                      <input
                        type="text"
                        value={editingProduct.seoTitle || ''}
                        onChange={(e) => setEditingProduct({ ...editingProduct, seoTitle: e.target.value })}
                        placeholder="e.g. Sony WH-1000XM5 Deal 2026: Best US Amazon Price ($348)"
                        className="w-full bg-zinc-950 border border-zinc-700 rounded-lg px-3 py-2 text-zinc-100 focus:outline-none focus:border-emerald-500 font-medium"
                      />
                    </div>

                    {/* SEO Meta Description */}
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="font-semibold text-zinc-300">
                          Google Search Meta Description
                        </label>
                        <span className={`text-[10px] font-mono ${
                          (editingProduct.seoDescription || '').length > 165 ? 'text-rose-400' : 'text-emerald-400'
                        }`}>
                          {(editingProduct.seoDescription || '').length} / 165 chars
                        </span>
                      </div>
                      <textarea
                        rows={2}
                        value={editingProduct.seoDescription || ''}
                        onChange={(e) => setEditingProduct({ ...editingProduct, seoDescription: e.target.value })}
                        placeholder="e.g. Comprehensive US review and live price check. Compare genuine Amazon prices with Prime 2-day delivery..."
                        className="w-full bg-zinc-950 border border-zinc-700 rounded-lg px-3 py-2 text-zinc-100 focus:outline-none focus:border-emerald-500"
                      />
                    </div>

                    {/* SEO Slug */}
                    <div>
                      <label className="font-semibold text-zinc-300 block mb-1">
                        Canonical URL Slug (Keyword-Rich URL)
                      </label>
                      <div className="flex items-center">
                        <span className="bg-zinc-800 text-zinc-400 px-3 py-2 rounded-l-lg border border-r-0 border-zinc-700 font-mono text-[11px]">
                          /product/
                        </span>
                        <input
                          type="text"
                          value={editingProduct.slug || ''}
                          onChange={(e) => setEditingProduct({ ...editingProduct, slug: createSlug(e.target.value) })}
                          placeholder="sony-wh-1000xm5-best-deals-2026"
                          className="w-full bg-zinc-950 border border-zinc-700 rounded-r-lg px-3 py-2 text-zinc-100 focus:outline-none focus:border-emerald-500 font-mono text-xs"
                        />
                      </div>
                    </div>

                    {/* Search Keywords Tags */}
                    <div>
                      <label className="font-semibold text-zinc-300 block mb-1">
                        Target Commercial Search Keywords
                      </label>
                      <div className="flex flex-wrap gap-1.5 mb-2">
                        {(editingProduct.seoKeywords || []).map((kw, i) => (
                          <span
                            key={i}
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-zinc-800 text-emerald-300 border border-emerald-500/30 text-[10px]"
                          >
                            <span>#{kw}</span>
                            <button
                              type="button"
                              onClick={() => {
                                const updated = (editingProduct.seoKeywords || []).filter((_, idx) => idx !== i);
                                setEditingProduct({ ...editingProduct, seoKeywords: updated });
                              }}
                              className="hover:text-rose-400"
                            >
                              ×
                            </button>
                          </span>
                        ))}
                      </div>

                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={keywordInput}
                          onChange={(e) => setKeywordInput(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              if (keywordInput.trim()) {
                                const current = editingProduct.seoKeywords || [];
                                setEditingProduct({
                                  ...editingProduct,
                                  seoKeywords: [...current, keywordInput.trim().toLowerCase()]
                                });
                                setKeywordInput('');
                              }
                            }
                          }}
                          placeholder="Add keyword (e.g. best headphones 2026) and press Enter"
                          className="flex-1 bg-zinc-950 border border-zinc-700 rounded-lg px-3 py-1.5 text-zinc-100 focus:outline-none focus:border-emerald-500"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            if (keywordInput.trim()) {
                              const current = editingProduct.seoKeywords || [];
                              setEditingProduct({
                                ...editingProduct,
                                seoKeywords: [...current, keywordInput.trim().toLowerCase()]
                              });
                              setKeywordInput('');
                            }
                          }}
                          className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-750 text-zinc-200 border border-zinc-700"
                        >
                          Add Tag
                        </button>
                      </div>
                    </div>

                    {/* Instant Indexing checkbox notice */}
                    <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 flex items-center gap-2 text-[11px]">
                      <CheckCircle2 className="w-4 h-4 flex-shrink-0 text-emerald-400" />
                      <span>
                        Automatic Googlebot Ping: Saving this product will automatically queue it for instant Google Indexing Bot submission!
                      </span>
                    </div>
                  </div>
                </div>

                {/* Action buttons */}
                <div className="flex items-center justify-between gap-3 pt-3 border-t border-zinc-800">
                  {editingProduct.id && products.some(p => p.id === editingProduct.id) ? (
                    <button
                      type="button"
                      onClick={() => {
                        const prod = products.find(p => p.id === editingProduct.id);
                        if (prod) {
                          setProductToDelete(prod);
                        }
                      }}
                      className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 text-xs font-semibold transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" /> Delete Product
                    </button>
                  ) : <div />}

                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => setIsEditingProduct(false)}
                      className="px-4 py-2 rounded-lg bg-zinc-850 hover:bg-zinc-800 text-zinc-300 font-medium"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold shadow-md"
                    >
                      Save Product
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Delete Product Custom Confirmation Modal */}
        {productToDelete && (
          <div className="absolute inset-0 z-50 bg-black/85 backdrop-blur-md p-6 flex items-center justify-center animate-in fade-in">
            <div className="w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-2xl p-6 text-center space-y-4 shadow-2xl">
              <div className="w-12 h-12 rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/30 mx-auto flex items-center justify-center">
                <Trash2 className="w-6 h-6" />
              </div>

              <div>
                <h3 className="text-base font-bold text-white">Delete This Product?</h3>
                <p className="text-xs text-zinc-400 mt-1 line-clamp-2">
                  Are you sure you want to permanently delete <strong className="text-zinc-200">"{productToDelete.title}"</strong> from your store?
                </p>
              </div>

              <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-850 flex items-center gap-3 text-left">
                <img src={productToDelete.imageUrl} alt="" className="w-12 h-12 rounded object-cover border border-zinc-800" />
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-semibold text-zinc-200 truncate">{productToDelete.title}</p>
                  <p className="text-[11px] text-zinc-400 font-mono">${productToDelete.price.toFixed(2)} • {productToDelete.brand}</p>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setProductToDelete(null)}
                  className="w-1/2 py-2.5 rounded-lg bg-zinc-800 hover:bg-zinc-750 text-zinc-300 font-semibold text-xs transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onDeleteProduct(productToDelete.id);
                    setProductToDelete(null);
                    setIsEditingProduct(false);
                  }}
                  className="w-1/2 py-2.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition-all shadow-md shadow-rose-600/20"
                >
                  Yes, Delete Product
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
