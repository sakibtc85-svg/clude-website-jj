import React, { useState } from 'react';
import { 
  X, 
  Star, 
  ExternalLink, 
  Heart, 
  ShieldCheck, 
  Truck, 
  RotateCcw, 
  Lock, 
  Check, 
  Share2, 
  Award,
  Sparkles,
  Copy,
  CheckCircle2
} from 'lucide-react';
import { Product } from '../types';
import { generateProductJsonLd } from '../utils/seoEngine';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onBuyAmazon: (product: Product) => void;
  isWishlisted: boolean;
  onToggleWishlist: (productId: string) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onBuyAmazon,
  isWishlisted,
  onToggleWishlist,
}) => {
  const [copied, setCopied] = useState(false);

  if (!product) return null;

  const discountPercent = product.originalPrice 
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100) 
    : 0;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(product.affiliateUrl || window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      {/* Schema.org Product Rich Snippet for Google Search Crawler */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(generateProductJsonLd(product)),
        }}
      />
      <div 
        className="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl text-zinc-100 p-6 md:p-8 no-scrollbar"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-zinc-400 hover:text-white rounded-lg bg-zinc-800/80 hover:bg-zinc-850 transition-colors z-10"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Left Column: Image showcase */}
          <div className="flex flex-col gap-4">
            <div className="relative aspect-square w-full rounded-xl bg-zinc-950 border border-zinc-800 overflow-hidden flex items-center justify-center">
              <img
                src={product.imageUrl}
                alt={product.title}
                className="w-full h-full object-cover object-center"
              />
              {product.isBestSeller && (
                <div className="absolute top-3 left-3 bg-amber-500 text-zinc-950 text-xs font-bold px-2.5 py-1 rounded shadow">
                  #1 Best Seller in {product.category}
                </div>
              )}
            </div>

            {/* Micro Trust Guarantee Box */}
            <div className="p-4 rounded-xl bg-zinc-950/60 border border-zinc-800/80 space-y-2 text-xs text-zinc-400">
              <div className="flex items-center gap-2 text-zinc-300 font-semibold">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                Verified Amazon US Guarantee
              </div>
              <div className="grid grid-cols-2 gap-2 text-[11px] pt-1">
                <span className="flex items-center gap-1.5">
                  <Truck className="w-3.5 h-3.5 text-zinc-400" /> FREE Prime Delivery
                </span>
                <span className="flex items-center gap-1.5">
                  <RotateCcw className="w-3.5 h-3.5 text-zinc-400" /> 30-Day US Returns
                </span>
                <span className="flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-zinc-400" /> SSL Secure 256-Bit
                </span>
                <span className="flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5 text-zinc-400" /> Amazon A-to-z Protected
                </span>
              </div>
            </div>
          </div>

          {/* Right Column: Details & Primary Amazon Buy Button */}
          <div className="flex flex-col justify-between space-y-6">
            <div>
              {/* Category, Brand, ASIN */}
              <div className="flex items-center gap-2 text-xs text-zinc-400 mb-2">
                <span className="px-2 py-0.5 rounded bg-zinc-800 text-amber-400 font-semibold uppercase tracking-wider text-[10px]">
                  {product.brand}
                </span>
                <span>•</span>
                <span>ASIN: {product.asin}</span>
                <span>•</span>
                <span className="text-zinc-500">{product.category}</span>
              </div>

              {/* Title */}
              <h1 className="text-xl md:text-2xl font-bold text-white leading-snug mb-3">
                {product.title}
              </h1>

              {/* Ratings */}
              <div className="flex items-center gap-3 mb-4">
                <div className="flex items-center text-amber-400">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < Math.floor(product.rating)
                          ? 'fill-amber-400 text-amber-400'
                          : 'text-zinc-600'
                      }`}
                    />
                  ))}
                  <span className="ml-1.5 font-bold text-sm text-zinc-100">{product.rating}</span>
                </div>
                <span className="text-xs text-zinc-400">
                  {product.reviewCount.toLocaleString()} global verified ratings
                </span>
              </div>

              {/* Price Row */}
              <div className="p-4 rounded-xl bg-zinc-950/80 border border-zinc-800/90 mb-5">
                <div className="flex items-baseline gap-3">
                  <span className="text-3xl font-extrabold text-white">
                    ${product.price.toFixed(2)}
                  </span>
                  {product.originalPrice && product.originalPrice > product.price && (
                    <>
                      <span className="text-sm text-zinc-500 line-through">
                        ${product.originalPrice.toFixed(2)}
                      </span>
                      <span className="text-xs font-bold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded">
                        Save ${(product.originalPrice - product.price).toFixed(2)} ({discountPercent}%)
                      </span>
                    </>
                  )}
                </div>
                
                {product.primeEligible && (
                  <div className="mt-2 text-xs text-sky-400 flex items-center gap-1 font-medium">
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                    <span>Prime Members get FREE Two-Day Shipping to US addresses</span>
                  </div>
                )}
              </div>

              {/* Description */}
              <p className="text-sm text-zinc-300 leading-relaxed mb-4">
                {product.description}
              </p>

              {/* Bullet Features */}
              <div className="mb-6">
                <h4 className="text-xs font-bold text-zinc-400 uppercase tracking-wider mb-2.5">
                  Key Specifications & Highlights
                </h4>
                <ul className="space-y-1.5 text-xs text-zinc-300">
                  {product.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-amber-400 mt-0.5">•</span>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="space-y-3 pt-4 border-t border-zinc-800">
              {/* PRIMARY CTA: BUY ON AMAZON */}
              <button
                onClick={() => onBuyAmazon(product)}
                className="w-full flex items-center justify-center gap-2.5 py-3.5 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-[0.99] text-zinc-950 font-extrabold text-sm sm:text-base transition-all shadow-xl shadow-amber-500/10"
              >
                <span>Buy on Amazon</span>
                <ExternalLink className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-between text-xs text-zinc-400 px-1">
                <button
                  onClick={() => onToggleWishlist(product.id)}
                  className="flex items-center gap-1.5 hover:text-zinc-200 transition-colors"
                >
                  <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-rose-500 text-rose-500' : ''}`} />
                  <span>{isWishlisted ? 'Saved in Wishlist' : 'Add to Wishlist'}</span>
                </button>

                <button
                  onClick={handleCopyLink}
                  className="flex items-center gap-1.5 hover:text-zinc-200 transition-colors"
                >
                  {copied ? (
                    <>
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      <span className="text-emerald-400">Link Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      <span>Share Product</span>
                    </>
                  )}
                </button>
              </div>

              {/* Affiliate Disclose Notice */}
              <p className="text-[11px] text-zinc-500 text-center leading-tight">
                🔒 You will be securely directed to Amazon.com with our affiliate referral tag. Prices and availability may change; the price shown on Amazon at checkout is final.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
