import React from 'react';
import { 
  Star, 
  ExternalLink, 
  Heart, 
  Check, 
  Eye, 
  Flame, 
  Award,
  ShoppingBag
} from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onOpenDetail: (product: Product) => void;
  onBuyAmazon: (product: Product) => void;
  isWishlisted: boolean;
  onToggleWishlist: (productId: string) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onOpenDetail,
  onBuyAmazon,
  isWishlisted,
  onToggleWishlist,
}) => {
  const discountPercent = product.originalPrice 
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100) 
    : 0;

  return (
    <div className="group relative bg-zinc-900/70 hover:bg-zinc-900 border border-zinc-800/80 hover:border-zinc-700 rounded-xl overflow-hidden transition-all duration-200 flex flex-col justify-between hover:shadow-xl hover:shadow-black/40">
      {/* Top Media Container */}
      <div className="relative aspect-square w-full bg-zinc-950/60 overflow-hidden cursor-pointer" onClick={() => onOpenDetail(product)}>
        {/* Badges */}
        <div className="absolute top-2.5 left-2.5 z-10 flex flex-col gap-1.5 items-start">
          {product.isBestSeller && (
            <span className="inline-flex items-center gap-1 bg-amber-500 text-zinc-950 text-[10px] font-bold px-2 py-0.5 rounded shadow-sm">
              <Award className="w-3 h-3" /> #1 Best Seller
            </span>
          )}
          {discountPercent > 0 && (
            <span className="inline-flex items-center gap-0.5 bg-rose-500/90 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow-sm">
              <Flame className="w-3 h-3" /> {discountPercent}% OFF
            </span>
          )}
          {product.isChoice && !product.isBestSeller && (
            <span className="inline-flex items-center gap-1 bg-zinc-800 text-amber-400 border border-amber-500/30 text-[10px] font-semibold px-2 py-0.5 rounded">
              Amazon's Choice
            </span>
          )}
        </div>

        {/* Wishlist Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleWishlist(product.id);
          }}
          className={`absolute top-2.5 right-2.5 z-10 p-2 rounded-full backdrop-blur-md transition-all ${
            isWishlisted
              ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
              : 'bg-zinc-950/60 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-900 border border-zinc-800'
          }`}
          title={isWishlisted ? 'Remove from Wishlist' : 'Save to Wishlist'}
        >
          <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-rose-500 text-rose-500' : ''}`} />
        </button>

        {/* Product Image */}
        <img
          src={product.imageUrl}
          alt={product.title}
          loading="lazy"
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
        />

        {/* Quick View Overlay Button */}
        <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
          <span className="px-3 py-1.5 rounded-lg bg-zinc-900/90 text-zinc-200 border border-zinc-700 text-xs font-medium flex items-center gap-1.5 shadow-lg">
            <Eye className="w-3.5 h-3.5" /> Quick View
          </span>
        </div>
      </div>

      {/* Body Information */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Brand & Category */}
          <div className="flex items-center justify-between text-[11px] text-zinc-400 mb-1">
            <span className="font-semibold uppercase tracking-wider text-amber-400/90">{product.brand}</span>
            <span className="truncate max-w-[120px] text-zinc-500">{product.category}</span>
          </div>

          {/* Product Title */}
          <h3 
            onClick={() => onOpenDetail(product)}
            className="text-sm font-semibold text-zinc-100 line-clamp-2 hover:text-amber-400 cursor-pointer transition-colors leading-snug mb-2"
            title={product.title}
          >
            {product.title}
          </h3>

          {/* Ratings & Reviews */}
          <div className="flex items-center gap-2 mb-3">
            <div className="flex items-center text-amber-400 text-xs">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              <span className="ml-1 font-bold">{product.rating}</span>
            </div>
            <span className="text-[11px] text-zinc-500">
              ({product.reviewCount.toLocaleString()} US reviews)
            </span>
          </div>
        </div>

        {/* Price & Primary CTA */}
        <div>
          {/* Pricing Row */}
          <div className="flex items-baseline gap-2 mb-2">
            <span className="text-xl font-extrabold text-white">
              ${product.price.toFixed(2)}
            </span>
            {product.originalPrice && product.originalPrice > product.price && (
              <span className="text-xs text-zinc-500 line-through">
                ${product.originalPrice.toFixed(2)}
              </span>
            )}
            {product.primeEligible && (
              <span className="ml-auto inline-flex items-center gap-1 text-[11px] font-semibold text-sky-400">
                <Check className="w-3 h-3 text-sky-400 stroke-[3]" />
                <span className="italic font-bold">prime</span>
              </span>
            )}
          </div>

          <p className="text-[11px] text-emerald-400/90 font-medium mb-3 flex items-center gap-1">
            {product.inStock ? (product.primeEligible ? '✓ In Stock • Prime eligible' : '✓ In Stock') : 'Currently unavailable'}
          </p>

          {/* Action Buttons: BUY ON AMAZON (Primary Hyperlink CTA) */}
          <div className="grid grid-cols-1 gap-2 pt-1 border-t border-zinc-800/80">
            <button
              onClick={() => onBuyAmazon(product)}
              className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-lg bg-amber-500 hover:bg-amber-400 active:scale-[0.99] text-zinc-950 font-bold text-xs transition-all shadow-md shadow-amber-500/10 group/btn"
              title="Redirect to Amazon US to complete secure checkout"
            >
              <span>Buy on Amazon</span>
              <ExternalLink className="w-3.5 h-3.5 group-hover/btn:translate-x-0.5 transition-transform" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
