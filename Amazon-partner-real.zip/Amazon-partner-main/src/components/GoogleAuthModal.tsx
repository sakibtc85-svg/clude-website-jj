import React, { useState } from 'react';
import { X, CheckCircle2, Shield, Lock, Sparkles, ArrowRight } from 'lucide-react';
import { UserProfile } from '../types';

interface GoogleAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: UserProfile) => void;
  defaultEmail?: string;
}

export const GoogleAuthModal: React.FC<GoogleAuthModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  defaultEmail = '',
}) => {
  const [customName, setCustomName] = useState('');
  const [customEmail, setCustomEmail] = useState(defaultEmail);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleQuickSignIn = (name: string, email: string, avatarUrl: string) => {
    setIsSubmitting(true);
    setTimeout(() => {
      const newUser: UserProfile = {
        id: 'usr-' + Date.now(),
        name,
        email,
        avatar: avatarUrl,
        provider: 'google',
        savedProducts: [],
        recentClicks: [],
        createdAt: new Date().toISOString(),
      };
      setIsSubmitting(false);
      onSuccess(newUser);
      onClose();
    }, 600);
  };

  const handleCustomSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customEmail) return;
    const nameToUse = customName.trim() || customEmail.split('@')[0];
    const avatar = `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(nameToUse)}&backgroundColor=f59e0b`;
    handleQuickSignIn(nameToUse, customEmail, avatar);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div 
        className="relative w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl p-6 sm:p-8 text-zinc-100"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-zinc-400 hover:text-white bg-zinc-800 hover:bg-zinc-750 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center space-y-2 mb-6">
          <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center mx-auto shadow-md">
            <svg className="w-6 h-6" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
            </svg>
          </div>
          <h2 className="text-xl font-bold text-white">Save your wishlist</h2>
          <p className="text-xs text-zinc-400">
            Sync saved Amazon deals, get US price drop alerts, and track your wishlist.
          </p>
        </div>

        <div className="relative my-4 text-center">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-zinc-800" />
          </div>
          <span className="relative px-3 bg-zinc-900 text-[10px] uppercase font-bold text-zinc-500">
            Your details
          </span>
        </div>

        {/* Custom Input */}
        <form onSubmit={handleCustomSignIn} className="space-y-3 text-xs">
          <div>
            <label className="font-medium text-zinc-300 block mb-1">Your Full Name</label>
            <input
              type="text"
              placeholder="e.g. Alex Morgan"
              value={customName}
              onChange={(e) => setCustomName(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 text-zinc-100 focus:outline-none focus:border-amber-500"
            />
          </div>

          <div>
            <label className="font-medium text-zinc-300 block mb-1">Email Address</label>
            <input
              type="email"
              required
              placeholder="name@gmail.com"
              value={customEmail}
              onChange={(e) => setCustomEmail(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 text-zinc-100 focus:outline-none focus:border-amber-500"
            />
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-2.5 rounded-lg bg-white hover:bg-zinc-100 active:scale-[0.99] text-zinc-900 font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all"
          >
            {isSubmitting ? 'Saving...' : 'Continue'}
          </button>
        </form>

        <p className="text-[10px] text-zinc-500 text-center mt-4 flex items-center justify-center gap-1">
          <Lock className="w-3 h-3 text-zinc-600" />
          Stored only in this browser • No spam
        </p>
      </div>
    </div>
  );
};
