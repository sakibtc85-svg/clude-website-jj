import React from 'react';
import { X, Trash2, ExternalLink, Heart, ShoppingBag, ArrowRight } from 'lucide-react';
import { Product } from '../types';

interface WishlistDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  wishlistIds: string[];
  onRemoveFromWishlist: (productId: string) => void;
  onClearWishlist: () => void;
  onBuyAmazon: (product: Product) => void;
  onOpenDetail: (product: Product) => void;
}

export const WishlistDrawer: React.FC<WishlistDrawerProps> = ({
  isOpen,
  onClose,
  products,
  wishlistIds,
  onRemoveFromWishlist,
  onClearWishlist,
  onBuyAmazon,
  onOpenDetail,
}) => {
  if (!isOpen) return null;

  const wishlistedProducts = products.filter(p => wishlistIds.includes(p.id));
  const totalValue = wishlistedProducts.reduce((sum, p) => sum + p.price, 0);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/70 backdrop-blur-sm animate-in fade-in">
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div 
          className="w-screen max-w-md bg-zinc-950 border-l border-zinc-800 text-zinc-100 flex flex-col shadow-2xl"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="p-5 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/60">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-lg bg-rose-500/10 text-rose-400 border border-rose-500/20">
                <Heart className="w-5 h-5 fill-rose-500 text-rose-500" />
              </div>
              <div>
                <h3 className="font-bold text-white text-base">Saved Amazon Items</h3>
                <p className="text-xs text-zinc-400">{wishlistedProducts.length} items in your wishlist</p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-zinc-400 hover:text-white bg-zinc-800 hover:bg-zinc-750 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* List Content */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {wishlistedProducts.length === 0 ? (
              <div className="text-center py-16 space-y-3">
                <div className="w-12 h-12 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center mx-auto text-zinc-600">
                  <Heart className="w-6 h-6" />
                </div>
                <h4 className="font-semibold text-zinc-300 text-sm">Your wishlist is empty</h4>
                <p className="text-xs text-zinc-500 max-w-xs mx-auto">
                  Click the heart icon on any product to save verified Amazon deals and track price changes.
                </p>
              </div>
            ) : (
              wishlistedProducts.map((prod) => (
                <div
                  key={prod.id}
                  className="p-3 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-zinc-750 flex gap-3 text-xs transition-colors"
                >
                  <img
                    src={prod.imageUrl}
                    alt={prod.title}
                    className="w-16 h-16 rounded-lg object-cover border border-zinc-800 flex-shrink-0 cursor-pointer"
                    onClick={() => {
                      onClose();
                      onOpenDetail(prod);
                    }}
                  />

                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between gap-1">
                        <span className="text-[10px] font-bold text-amber-400 uppercase">{prod.brand}</span>
                        <button
                          onClick={() => onRemoveFromWishlist(prod.id)}
                          className="text-zinc-500 hover:text-rose-400 transition-colors"
                          title="Remove"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <h4
                        className="font-medium text-zinc-200 line-clamp-1 hover:text-amber-400 cursor-pointer"
                        onClick={() => {
                          onClose();
                          onOpenDetail(prod);
                        }}
                      >
                        {prod.title}
                      </h4>
                    </div>

                    <div className="flex items-center justify-between pt-2">
                      <span className="font-extrabold text-white text-sm">
                        ${prod.price.toFixed(2)}
                      </span>

                      <button
                        onClick={() => onBuyAmazon(prod)}
                        className="flex items-center gap-1.5 px-3 py-1 rounded-md bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-[11px] transition-all"
                      >
                        <span>Buy on Amazon</span>
                        <ExternalLink className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer summary */}
          {wishlistedProducts.length > 0 && (
            <div className="p-5 border-t border-zinc-800 bg-zinc-900/80 space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-zinc-400">Total Saved Value</span>
                <span className="text-lg font-black text-white">${totalValue.toFixed(2)}</span>
              </div>

              <div className="flex items-center justify-between pt-1">
                <button
                  onClick={onClearWishlist}
                  className="text-zinc-500 hover:text-rose-400 text-[11px] transition-colors"
                >
                  Clear All
                </button>
                <p className="text-[10px] text-zinc-500">Free Prime shipping applies at Amazon</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
