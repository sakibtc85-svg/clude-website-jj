import React from 'react';
import { 
  Sparkles, 
  ShieldCheck, 
  Truck, 
  RotateCcw, 
  CheckCircle2, 
  Flame, 
  Search,
  ArrowRight
} from 'lucide-react';

interface HeroBannerProps {
  onSelectQuickFilter: (filter: string) => void;
  activeQuickFilter: string;
  totalProductsCount: number;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  onSelectQuickFilter,
  activeQuickFilter,
  totalProductsCount,
}) => {
  const quickPills = [
    { label: 'All Items', value: 'all' },
    { label: '🔥 Best Sellers', value: 'bestseller' },
    { label: '⚡ Prime Eligible', value: 'prime' },
    { label: '🏷️ Deals Under $150', value: 'under150' },
    { label: '🎧 Audio & Smart Tech', value: 'audio' },
    { label: '☕ Kitchen Favorites', value: 'kitchen' },
  ];

  return (
    <div className="relative border-b border-zinc-800/80 bg-gradient-to-b from-zinc-900/70 via-zinc-950 to-zinc-950 px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
      {/* Background subtle grid pattern */}
      <div className="absolute inset-0 bg-[radial-gradient(#27272a_1px,transparent_1px)] [background-size:24px_24px] opacity-25 pointer-events-none" />

      <div className="relative max-w-7xl mx-auto flex flex-col items-center text-center space-y-6">
        {/* US Verified Pill */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900 border border-zinc-700/80 text-xs text-zinc-300 shadow-sm">
          <span className="flex h-2 w-2 rounded-full bg-amber-400 animate-pulse" />
          <span className="font-semibold text-white">Amazon US Curated Catalog</span>
          <span className="text-zinc-500">•</span>
          <span className="text-amber-400 font-medium">100% Genuine Amazon Checkout</span>
        </div>

        {/* Main Headline */}
        <div className="max-w-3xl space-y-3">
          <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-[1.15]">
            Handpicked Tech & Lifestyle Essentials on <span className="text-amber-400">Amazon</span>.
          </h1>
          <p className="text-sm sm:text-base text-zinc-400 max-w-2xl mx-auto leading-relaxed">
            Every product is rigorously reviewed for durability, verified ratings, and genuine value. 
            Enjoy seamless Amazon 1-Click checkout, fast Prime 2-Day delivery, and hassle-free 30-day US returns.
          </p>
        </div>

        {/* Quick Filter Pills */}
        <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
          {quickPills.map((pill) => {
            const isActive = activeQuickFilter === pill.value;
            return (
              <button
                key={pill.value}
                onClick={() => onSelectQuickFilter(pill.value)}
                className={`text-xs font-semibold px-3.5 py-1.5 rounded-full transition-all ${
                  isActive
                    ? 'bg-amber-500 text-zinc-950 shadow-md shadow-amber-500/20'
                    : 'bg-zinc-900 text-zinc-300 hover:text-white hover:bg-zinc-800 border border-zinc-800'
                }`}
              >
                {pill.label}
              </button>
            );
          })}
        </div>

        {/* Trust Badges Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-8 pt-4 border-t border-zinc-850/80 w-full max-w-4xl text-left">
          <div className="flex items-center gap-2.5">
            <Truck className="w-4 h-4 text-amber-400 flex-shrink-0" />
            <div>
              <p className="text-xs font-bold text-zinc-200">Amazon Prime 2-Day</p>
              <p className="text-[11px] text-zinc-500">Fast US domestic delivery</p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <RotateCcw className="w-4 h-4 text-amber-400 flex-shrink-0" />
            <div>
              <p className="text-xs font-bold text-zinc-200">30-Day US Returns</p>
              <p className="text-[11px] text-zinc-500">Drop-off at Whole Foods & Kohl's</p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <div>
              <p className="text-xs font-bold text-zinc-200">A-to-z Guarantee</p>
              <p className="text-[11px] text-zinc-500">Official buyer protection</p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-sky-400 flex-shrink-0" />
            <div>
              <p className="text-xs font-bold text-zinc-200">Zero Extra Cost</p>
              <p className="text-[11px] text-zinc-500">Transparent affiliate pricing</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
