import React, { useState } from 'react';
import { 
  X, 
  ShieldCheck, 
  Mail, 
  MapPin, 
  Phone, 
  Send, 
  CheckCircle2, 
  ExternalLink, 
  HelpCircle, 
  Lock,
  RotateCcw,
  FileText
} from 'lucide-react';

export type PolicyType = 'contact' | 'disclosure' | 'refund' | 'privacy' | 'terms' | 'secure' | null;

interface PolicyModalsProps {
  currentPolicy: PolicyType;
  onClose: () => void;
}

export const PolicyModals: React.FC<PolicyModalsProps> = ({ currentPolicy, onClose }) => {
  const [contactSubmitted, setContactSubmitted] = useState(false);
  const [contactForm, setContactForm] = useState({ name: '', email: '', subject: 'Product Question', message: '' });

  if (!currentPolicy) return null;

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setContactSubmitted(true);
    setTimeout(() => {
      setContactSubmitted(false);
      onClose();
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div 
        className="relative w-full max-w-2xl max-h-[85vh] bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl p-6 md:p-8 overflow-y-auto text-zinc-200 no-scrollbar"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 rounded-lg text-zinc-400 hover:text-white bg-zinc-800 hover:bg-zinc-750 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* 1. CONTACT US */}
        {currentPolicy === 'contact' && (
          <div className="space-y-5">
            <div>
              <span className="text-amber-400 text-xs font-bold uppercase tracking-wider">Customer Support</span>
              <h2 className="text-xl font-bold text-white mt-1">Contact Our US Team</h2>
              <p className="text-xs text-zinc-400 mt-1">
                Have questions about a curated Amazon product recommendation or our website? We are here to help.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-zinc-950/70 border border-zinc-800 flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-zinc-200">US Headquarters</p>
                  <p className="text-zinc-500 text-[11px]">401 Congress Ave, Suite 1500<br />Austin, TX 78701</p>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-zinc-950/70 border border-zinc-800 flex items-start gap-2.5">
                <Mail className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-zinc-200">Email Inquiries</p>
                  <p className="text-zinc-500 text-[11px]">support@apexpickshq.com<br />24/7 Monitored</p>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-zinc-950/70 border border-zinc-800 flex items-start gap-2.5">
                <Phone className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-zinc-200">Phone Support</p>
                  <p className="text-zinc-500 text-[11px]">+1 (800) 555-APEX<br />9am - 6pm EST</p>
                </div>
              </div>
            </div>

            {contactSubmitted ? (
              <div className="p-6 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-center space-y-2">
                <CheckCircle2 className="w-8 h-8 mx-auto" />
                <h4 className="font-bold text-sm">Message Sent Successfully!</h4>
                <p className="text-xs text-zinc-300">
                  Thank you for reaching out. A representative will respond to your inquiry within 12 business hours.
                </p>
              </div>
            ) : (
              <form onSubmit={handleContactSubmit} className="space-y-3.5 text-xs">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="font-semibold text-zinc-300 block mb-1">Your Name</label>
                    <input
                      type="text"
                      required
                      placeholder="Jane Doe"
                      value={contactForm.name}
                      onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 text-zinc-100 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                  <div>
                    <label className="font-semibold text-zinc-300 block mb-1">Email Address</label>
                    <input
                      type="email"
                      required
                      placeholder="jane@example.com"
                      value={contactForm.email}
                      onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 text-zinc-100 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="font-semibold text-zinc-300 block mb-1">Inquiry Subject</label>
                  <select
                    value={contactForm.subject}
                    onChange={(e) => setContactForm({ ...contactForm, subject: e.target.value })}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 text-zinc-100 focus:outline-none focus:border-amber-500"
                  >
                    <option value="Product Question">Product Recommendation Question</option>
                    <option value="Amazon Order Assistance">Amazon Order Redirection Assistance</option>
                    <option value="Affiliate Partnership">Partnership / Brand Collaboration</option>
                    <option value="General Feedback">Website Feedback / Bug Report</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-zinc-300 block mb-1">Message</label>
                  <textarea
                    rows={4}
                    required
                    placeholder="How can we assist you with our Amazon curated picks?"
                    value={contactForm.message}
                    onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 text-zinc-100 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all"
                >
                  <Send className="w-3.5 h-3.5" /> Submit Message
                </button>
              </form>
            )}
          </div>
        )}

        {/* 2. FTC AFFILIATE DISCLOSURE */}
        {currentPolicy === 'disclosure' && (
          <div className="space-y-4 text-xs">
            <div className="flex items-center gap-2 text-amber-400">
              <ShieldCheck className="w-5 h-5" />
              <h2 className="text-lg font-bold text-white">Amazon Associates Program Disclosure</h2>
            </div>

            <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 font-medium leading-relaxed">
              "As an Amazon Associate, Amazon Partner earns from qualifying purchases made through links on this website."
            </div>

            <div className="space-y-3 text-zinc-300 leading-relaxed">
              <p>
                In compliance with the Federal Trade Commission (FTC) guidelines and the Amazon Services LLC Associates Program Operating Agreement, please be advised that some links on this site are affiliate hyperlinks.
              </p>
              <h4 className="font-bold text-white text-sm pt-2">What does this mean for you?</h4>
              <p>
                When you click on a product link or button marked "Buy on Amazon" and make a purchase on Amazon.com, we may receive a small commission from Amazon at <strong>absolutely zero additional cost to you</strong>.
              </p>
              <h4 className="font-bold text-white text-sm pt-2">Pricing & Availability</h4>
              <p>
                Product prices and availability are accurate as of the date and time indicated and are subject to change. Any price and availability information displayed on Amazon.com at the time of purchase will apply to the purchase of this product.
              </p>
              <p>
                Amazon and the Amazon logo are trademarks of Amazon.com, Inc. or its affiliates.
              </p>
            </div>
          </div>
        )}

        {/* 3. REFUND POLICY */}
        {currentPolicy === 'refund' && (
          <div className="space-y-4 text-xs">
            <div className="flex items-center gap-2 text-amber-400">
              <RotateCcw className="w-5 h-5" />
              <h2 className="text-lg font-bold text-white">US Refund & Return Policy</h2>
            </div>

            <div className="space-y-3 text-zinc-300 leading-relaxed">
              <p>
                Because Amazon Partner connects you directly to Amazon.com for checkout, all purchases made through our referral links are fully protected by <strong>Amazon’s Official 30-Day US Return Policy</strong> and the <strong>Amazon A-to-z Guarantee</strong>.
              </p>

              <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-2">
                <h4 className="font-bold text-white">Key Return Benefits for US Customers:</h4>
                <ul className="list-disc list-inside space-y-1 text-zinc-400">
                  <li>30-day return window on most physical products shipped by Amazon</li>
                  <li>Free return drop-offs at thousands of US locations including Kohl's, Whole Foods Market, and The UPS Store</li>
                  <li>No box or label required at participating drop-off hubs</li>
                  <li>Instant refund issued to your original payment method or Amazon Gift Card balance</li>
                </ul>
              </div>

              <h4 className="font-bold text-white text-sm pt-2">How to Request a Return or Replacement:</h4>
              <ol className="list-decimal list-inside space-y-1.5 text-zinc-400">
                <li>Log in to your Amazon.com account.</li>
                <li>Navigate to <span className="text-zinc-200 font-medium">"Your Orders"</span>.</li>
                <li>Select <span className="text-zinc-200 font-medium">"Return or replace items"</span> next to the item.</li>
                <li>Choose your preferred drop-off location and present the return QR code.</li>
              </ol>

              <p className="text-zinc-500 text-[11px] pt-2">
                If you encounter any difficulty reaching Amazon customer support, our team can guide you. Contact us anytime at support@apexpickshq.com.
              </p>
            </div>
          </div>
        )}

        {/* 4. PRIVACY POLICY */}
        {currentPolicy === 'privacy' && (
          <div className="space-y-4 text-xs">
            <div className="flex items-center gap-2 text-amber-400">
              <Lock className="w-5 h-5" />
              <h2 className="text-lg font-bold text-white">Privacy Policy (US & CCPA Compliant)</h2>
            </div>

            <div className="space-y-3 text-zinc-300 leading-relaxed">
              <p>
                Effective Date: October 2026. Amazon Partner ("we", "our", or "us") respects your digital privacy and is dedicated to protecting personal information collected through our web portal.
              </p>
              <h4 className="font-bold text-white text-sm">1. Information We Collect</h4>
              <p>
                We do not collect sensitive credit card numbers or banking data on our servers. When you click an Amazon deal, Amazon Associates uses standard cookies to track affiliate referral attributions over 24 hours.
              </p>
              <h4 className="font-bold text-white text-sm">2. Google Sign-In</h4>
              <p>
                When you sign in using Google Login, we only receive your basic public profile information (name, email address, avatar) to sync your saved items and personalized price tracking preferences. We never share or sell this data to third parties.
              </p>
              <h4 className="font-bold text-white text-sm">3. California Consumer Privacy Act (CCPA) Rights</h4>
              <p>
                California residents have the right to request disclosure of personal data collected, request deletion, and opt-out of data sharing. We do not sell personal information under CCPA definitions.
              </p>
            </div>
          </div>
        )}

        {/* 5. TERMS OF SERVICE */}
        {currentPolicy === 'terms' && (
          <div className="space-y-4 text-xs">
            <div className="flex items-center gap-2 text-amber-400">
              <FileText className="w-5 h-5" />
              <h2 className="text-lg font-bold text-white">Terms of Service</h2>
            </div>

            <div className="space-y-3 text-zinc-300 leading-relaxed">
              <p>
                By using Amazon Partner, you agree to comply with and be bound by the following terms of use.
              </p>
              <h4 className="font-bold text-white text-sm">1. Editorial Recommendations</h4>
              <p>
                Amazon Partner curates products based on specifications, ratings, and genuine value for US consumers. Product descriptions and prices are derived from manufacturer and merchant listings.
              </p>
              <h4 className="font-bold text-white text-sm">2. External Merchant Agreements</h4>
              <p>
                Transactions, order fulfillment, shipping, customer support, and warranty claims take place under Amazon.com's Terms of Use. Amazon Partner is an independent curation and affiliate portal and is not liable for merchant delivery disruptions.
              </p>
            </div>
          </div>
        )}

        {/* 6. SECURE CHECKOUT INTEGRATION */}
        {currentPolicy === 'secure' && (
          <div className="space-y-4 text-xs">
            <div className="flex items-center gap-2 text-emerald-400">
              <ShieldCheck className="w-5 h-5" />
              <h2 className="text-lg font-bold text-white">Secure Checkout & Amazon Protection</h2>
            </div>

            <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-3 text-zinc-300 leading-relaxed">
              <p>
                Your privacy and financial security are paramount. Here is how checkout works on Amazon Partner:
              </p>
              <div className="space-y-2">
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-emerald-500/10 text-emerald-400 font-bold flex items-center justify-center flex-shrink-0 text-[10px]">1</span>
                  <span><strong>Zero payment data stored on our site:</strong> You never enter credit card, PayPal, or billing addresses directly on our servers.</span>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-emerald-500/10 text-emerald-400 font-bold flex items-center justify-center flex-shrink-0 text-[10px]">2</span>
                  <span><strong>Official Amazon 256-Bit SSL Encryption:</strong> When you click "Buy on Amazon", you are smoothly directed to Amazon’s battle-tested infrastructure.</span>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-emerald-500/10 text-emerald-400 font-bold flex items-center justify-center flex-shrink-0 text-[10px]">3</span>
                  <span><strong>Amazon 1-Click & Prime Delivery:</strong> Your existing Amazon addresses, Prime status, and gift cards apply instantly.</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
