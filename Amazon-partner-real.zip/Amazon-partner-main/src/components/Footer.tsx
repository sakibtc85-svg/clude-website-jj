import React, { useState } from 'react';
import { 
  ShieldCheck, 
  MapPin, 
  Mail, 
  ExternalLink, 
  Heart, 
  Lock, 
  CheckCircle2, 
  ArrowRight
} from 'lucide-react';
import { PolicyType } from './PolicyModals';

interface FooterProps {
  onOpenPolicy: (policy: 'contact' | 'disclosure' | 'refund' | 'privacy' | 'terms' | 'secure') => void;
  onOpenAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenPolicy, onOpenAdmin }) => {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail) return;
    setSubscribed(true);
    setTimeout(() => {
      setNewsletterEmail('');
      setSubscribed(false);
    }, 4000);
  };

  return (
    <footer className="bg-zinc-950 border-t border-zinc-850 text-zinc-400 text-xs mt-20">
      {/* Newsletter / Price Alert Bar */}
      <div className="border-b border-zinc-850/80 bg-zinc-900/40 py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center md:text-left">
            <h4 className="text-base font-bold text-white flex items-center justify-center md:justify-start gap-2">
              <Mail className="w-4 h-4 text-amber-400" />
              US Amazon Price Drop & Deal Alerts
            </h4>
            <p className="text-xs text-zinc-400">
              Get notified when top tech, audio, and kitchen essentials drop below historical lows. No spam, ever.
            </p>
          </div>

          <form onSubmit={handleSubscribe} className="flex w-full md:w-auto max-w-md gap-2">
            <input
              type="email"
              required
              placeholder="Enter your email for US deals..."
              value={newsletterEmail}
              onChange={(e) => setNewsletterEmail(e.target.value)}
              className="bg-zinc-950 border border-zinc-800 rounded-lg px-3.5 py-2 text-xs text-zinc-100 placeholder:text-zinc-500 focus:outline-none focus:border-amber-500 flex-1 md:w-64"
            />
            <button
              type="submit"
              className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs flex items-center gap-1.5 transition-all shadow-sm flex-shrink-0"
            >
              {subscribed ? 'Subscribed!' : 'Subscribe'}
            </button>
          </form>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          {/* Brand Info */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-zinc-900 border border-zinc-700 flex items-center justify-center shadow-sm">
                <span className="text-amber-400 font-black text-base">A</span>
                <span className="text-zinc-100 font-bold text-xs">P</span>
              </div>
              <span className="text-base font-extrabold text-white">
                Amazon <span className="text-amber-400">Partner</span>
              </span>
            </div>
            <p className="text-xs text-zinc-400 leading-relaxed">
              Curated premier tech, audio, and home gear for discerning American shoppers. Verified pricing, Prime 2-day domestic fulfillment, and authentic reviews.
            </p>
            <div className="flex items-center gap-2 text-[11px] text-zinc-500">
              <MapPin className="w-3.5 h-3.5 text-zinc-400" />
              <span>Headquartered in Austin, TX • Serving all 50 US States</span>
            </div>
          </div>

          {/* Quick Navigation */}
          <div className="space-y-3">
            <h5 className="font-bold text-zinc-200 text-xs uppercase tracking-wider">Store Categories</h5>
            <ul className="space-y-2 text-xs">
              <li><a href="#" className="hover:text-amber-400 transition-colors">Electronics & Tech</a></li>
              <li><a href="#" className="hover:text-amber-400 transition-colors">Smart Home & Audio</a></li>
              <li><a href="#" className="hover:text-amber-400 transition-colors">Kitchen & Appliances</a></li>
              <li><a href="#" className="hover:text-amber-400 transition-colors">Health & Fitness Trackers</a></li>
              <li><a href="#" className="hover:text-amber-400 transition-colors">Workstation & Ergonomics</a></li>
            </ul>
          </div>

          {/* Trust & Policies */}
          <div className="space-y-3">
            <h5 className="font-bold text-zinc-200 text-xs uppercase tracking-wider">Customer Care & Policies</h5>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onOpenPolicy('contact')} className="hover:text-amber-400 transition-colors">
                  Contact Us (Austin Support)
                </button>
              </li>
              <li>
                <button onClick={() => onOpenPolicy('refund')} className="hover:text-amber-400 transition-colors">
                  Refund & Return Policy (30 Days)
                </button>
              </li>
              <li>
                <button onClick={() => onOpenPolicy('secure')} className="hover:text-amber-400 transition-colors">
                  Secure Checkout Guarantee
                </button>
              </li>
              <li>
                <button onClick={() => onOpenPolicy('privacy')} className="hover:text-amber-400 transition-colors">
                  Privacy Policy (CCPA Compliant)
                </button>
              </li>
              <li>
                <button onClick={() => onOpenPolicy('terms')} className="hover:text-amber-400 transition-colors">
                  Terms of Service
                </button>
              </li>
            </ul>
          </div>

          {/* Amazon Associates Compliance */}
          <div className="space-y-3">
            <h5 className="font-bold text-zinc-200 text-xs uppercase tracking-wider">Affiliate Compliance</h5>
            <p className="text-[11px] text-zinc-400 leading-relaxed">
              Amazon Partner is a participant in the Amazon Services LLC Associates Program. When you purchase via our "Buy on Amazon" buttons, we earn a small commission without charging you a single cent more.
            </p>
            <div>
              <button
                onClick={() => onOpenPolicy('disclosure')}
                className="inline-flex items-center gap-1.5 text-amber-400 hover:text-amber-300 font-semibold text-xs"
              >
                Read Full FTC Disclosure <ExternalLink className="w-3 h-3" />
              </button>
            </div>
            <div className="pt-2">
              <button
                onClick={onOpenAdmin}
                className="text-[11px] text-zinc-500 hover:text-zinc-300 underline"
              >
                Merchant Admin Portal
              </button>
            </div>
          </div>
        </div>

        {/* Mandatory Amazon Associates Disclaimer Box */}
        <div className="p-4 rounded-xl bg-zinc-900/60 border border-zinc-850 text-[11px] text-zinc-400 leading-relaxed space-y-2">
          <p className="font-semibold text-zinc-300">
            AMAZON ASSOCIATES PROGRAM DISCLOSURE:
          </p>
          <p>
            Amazon Partner is an independent publication and participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to Amazon.com. Certain content that appears on this site comes from Amazon Services LLC. This content is provided 'as is' and is subject to change or removal at any time.
          </p>
          <p className="text-zinc-400">
            Amazon and the Amazon logo are trademarks of Amazon.com, Inc. or its affiliates.
          </p>
        </div>

        {/* Bottom copyright */}
        <div className="pt-6 mt-6 border-t border-zinc-850 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-zinc-400">
          <p>© {new Date().getFullYear()} Amazon Partner US Inc. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <Lock className="w-3 h-3 text-emerald-400" /> 256-Bit SSL Encrypted
            </span>
            <span>•</span>
            <span>Austin, Texas, USA</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
