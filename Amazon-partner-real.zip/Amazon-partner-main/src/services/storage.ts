import { Product, AffiliateClick, UserProfile, AdminSettings } from '../types';

async function req<T>(url: string, method = 'GET', body?: unknown): Promise<T> {
  const r = await fetch(url, {
    method,
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error((j as { error?: string }).error || r.statusText);
  return j as T;
}

// All store data lives on the server; only wishlist/profile stay in this visitor's browser.
export const api = {
  products: () => req<Product[]>('/api/products'),
  settings: () => req<AdminSettings>('/api/settings'),
  me: () => req<{ ok: boolean }>('/api/admin/me').then(r => r.ok).catch(() => false),
  login: (password: string) => req('/api/admin/login', 'POST', { password }).then(() => true).catch(() => false),
  logout: () => req('/api/admin/logout', 'POST', {}),
  clicks: () => req<AffiliateClick[]>('/api/admin/clicks'),
  saveProduct: (p: Product, isNew: boolean) =>
    isNew ? req<Product>('/api/products', 'POST', p) : req<Product>('/api/products/' + p.id, 'PUT', p),
  deleteProduct: (id: string) => req('/api/products/' + id, 'DELETE'),
  saveSettings: (s: AdminSettings) => req<AdminSettings>('/api/settings', 'PUT', s),
  bulkTag: (tag: string) => req<{ products: Product[] }>('/api/admin/bulk-tag', 'POST', { tag }),
  upload: (dataUrl: string) => req<{ url: string }>('/api/admin/upload', 'POST', { dataUrl }),
};

const read = <T,>(key: string, fallback: T): T => {
  try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : fallback; } catch { return fallback; }
};
const write = (key: string, v: unknown) => { try { localStorage.setItem(key, JSON.stringify(v)); } catch { /* quota */ } };

export const getUserSession = (): UserProfile | null => read('store_user_v2', null);
export const saveUserSession = (u: UserProfile | null): void => (u ? write('store_user_v2', u) : localStorage.removeItem('store_user_v2'));
export const getWishlist = (): string[] => read('store_wishlist_v2', []);
export const saveWishlist = (ids: string[]): void => write('store_wishlist_v2', ids);
