/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { api, getUserSession, saveUserSession, getWishlist, saveWishlist } from './services/storage';
import { Product, AffiliateClick, UserProfile, AdminSettings } from './types';
import { CATEGORIES } from './data/mockProducts';
import { Header } from './components/Header';
import { HeroBanner } from './components/HeroBanner';
import { ProductCard } from './components/ProductCard';
import { ProductDetailModal } from './components/ProductDetailModal';
import { AdminPanel } from './components/AdminPanel';
import { GoogleAuthModal } from './components/GoogleAuthModal';
import { WishlistDrawer } from './components/WishlistDrawer';
import { PolicyModals, PolicyType } from './components/PolicyModals';
import { Footer } from './components/Footer';
import { 
  Filter, 
  SlidersHorizontal, 
  ArrowUpDown, 
  Check, 
  Search, 
  ExternalLink, 
  AlertCircle,
  Sparkles,
  ShoppingBag
} from 'lucide-react';

export default function App() {
  // Core Store State
  const [products, setProducts] = useState<Product[]>([]);
  const [clicks, setClicks] = useState<AffiliateClick[]>([]);
  const [adminSettings, setAdminSettings] = useState<AdminSettings>({ affiliateTag: '', adminPasswordHash: '', defaultCommissionRate: 4, estimatedConversionRate: 8.5, siteTitle: '', contactEmail: '' });
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [wishlist, setWishlist] = useState<string[]>([]);

  // Navigation & Search State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [quickFilter, setQuickFilter] = useState('all');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating' | 'discount'>('featured');
  const [primeOnlyFilter, setPrimeOnlyFilter] = useState(false);
  const [maxPriceFilter, setMaxPriceFilter] = useState<number>(2000);

  // Modals & Panels State
  const [activeDetailProduct, setActiveDetailProduct] = useState<Product | null>(null);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isAdminAuthed, setIsAdminAuthed] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [currentPolicy, setCurrentPolicy] = useState<PolicyType>(null);

  // Redirection Feedback Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Load initial data from the server
  useEffect(() => {
    api.products().then(setProducts).catch(() => showToast('Could not load products.'));
    api.settings().then(setAdminSettings).catch(() => {});
    setCurrentUser(getUserSession());
    setWishlist(getWishlist());
    api.me().then(setIsAdminAuthed);
  }, []);
  useEffect(() => { if (isAdminAuthed) api.clicks().then(setClicks).catch(() => {}); }, [isAdminAuthed]);

  // Update wishlist in storage
  const handleToggleWishlist = (productId: string) => {
    let updated: string[];
    if (wishlist.includes(productId)) {
      updated = wishlist.filter(id => id !== productId);
    } else {
      updated = [...wishlist, productId];
    }
    setWishlist(updated);
    saveWishlist(updated);

    if (currentUser) {
      const updatedUser = { ...currentUser, savedProducts: updated };
      setCurrentUser(updatedUser);
      saveUserSession(updatedUser);
    }
  };

  const handleClearWishlist = () => {
    setWishlist([]);
    saveWishlist([]);
    if (currentUser) {
      const updatedUser = { ...currentUser, savedProducts: [] };
      setCurrentUser(updatedUser);
      saveUserSession(updatedUser);
    }
  };

  // Google Login Handlers
  const handleGoogleSignInSuccess = (user: UserProfile) => {
    // Merge existing local wishlist with user's saved items
    const mergedSaved = Array.from(new Set([...wishlist, ...user.savedProducts]));
    const fullUser = { ...user, savedProducts: mergedSaved };
    setCurrentUser(fullUser);
    saveUserSession(fullUser);
    setWishlist(mergedSaved);
    saveWishlist(mergedSaved);

    showToast(`Signed in as ${user.name}!`);
  };

  const handleSignOut = () => {
    setCurrentUser(null);
    saveUserSession(null);
    showToast('Signed out successfully.');
  };

  // Toast Helper
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  };

  // Click is logged + redirected server-side (/r/:id), so stats can't be faked from the browser
  const handleBuyOnAmazon = (product: Product) => {
    setProducts(prev => prev.map(p => p.id === product.id ? { ...p, clicksCount: (p.clicksCount || 0) + 1 } : p));
    showToast('Opening Amazon.com in a new tab...');
    window.open(`/r/${encodeURIComponent(product.id)}`, '_blank', 'noopener,noreferrer');
  };

  const fail = (e: unknown) => showToast(`Failed: ${(e as Error).message}`);
  const handleAdminAuth = async (password: string): Promise<boolean> => {
    const ok = await api.login(password);
    setIsAdminAuthed(ok);
    return ok;
  };
  const handleLogoutAdmin = () => { api.logout().catch(() => {}); setIsAdminAuthed(false); setClicks([]); };
  const handleSaveProduct = async (p: Product) => {
    try {
      const isNew = !products.some(x => x.id === p.id);
      const saved = await api.saveProduct(p, isNew);
      setProducts(prev => isNew ? [saved, ...prev] : prev.map(x => x.id === saved.id ? saved : x));
      showToast(`✓ "${saved.title.slice(0, 22)}..." saved.`);
    } catch (e) { fail(e); }
  };
  const handleDeleteProduct = async (id: string) => {
    try { await api.deleteProduct(id); setProducts(prev => prev.filter(p => p.id !== id)); showToast('Product removed.'); } catch (e) { fail(e); }
  };
  const handleSaveAdminSettings = async (s: AdminSettings) => {
    try { setAdminSettings(await api.saveSettings(s)); showToast('Admin settings saved.'); } catch (e) { fail(e); }
  };
  const handleBulkUpdateAffiliateTag = async (tag: string) => {
    try { const r = await api.bulkTag(tag); setProducts(r.products); setAdminSettings(s => ({ ...s, affiliateTag: tag })); } catch (e) { fail(e); }
  };

  // Filtered & Sorted Products
  const filteredProducts = useMemo(() => {
    return products.filter((prod) => {
      // 1. Text Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = prod.title.toLowerCase().includes(q);
        const matchesBrand = prod.brand.toLowerCase().includes(q);
        const matchesAsin = prod.asin.toLowerCase().includes(q);
        const matchesDesc = prod.description.toLowerCase().includes(q);
        if (!matchesTitle && !matchesBrand && !matchesAsin && !matchesDesc) {
          return false;
        }
      }

      // 2. Category Filter
      if (selectedCategory !== 'All' && prod.category !== selectedCategory) {
        return false;
      }

      // 3. Quick Pills
      if (quickFilter === 'bestseller' && !prod.isBestSeller) return false;
      if (quickFilter === 'prime' && !prod.primeEligible) return false;
      if (quickFilter === 'under150' && prod.price >= 150) return false;
      if (quickFilter === 'audio' && prod.category !== 'Smart Home & Audio') return false;
      if (quickFilter === 'kitchen' && prod.category !== 'Kitchen & Appliances') return false;

      // 4. Prime Only Toggle
      if (primeOnlyFilter && !prod.primeEligible) return false;

      // 5. Max Price Slider
      if (prod.price > maxPriceFilter) return false;

      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      if (sortBy === 'discount') {
        const discA = a.originalPrice ? (a.originalPrice - a.price) : 0;
        const discB = b.originalPrice ? (b.originalPrice - b.price) : 0;
        return discB - discA;
      }
      // 'featured' default: prioritize best sellers, high ratings, and recent clicks
      if (a.isBestSeller && !b.isBestSeller) return -1;
      if (!a.isBestSeller && b.isBestSeller) return 1;
      return (b.clicksCount || 0) - (a.clicksCount || 0);
    });
  }, [products, searchQuery, selectedCategory, quickFilter, primeOnlyFilter, maxPriceFilter, sortBy]);

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-amber-500/30 selection:text-amber-200">
      {/* Schema.org WebSite & Organization Structured Data for Googlebot */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'WebSite',
            name: 'Amazon Partner US',
            url: 'https://amazonpartnerus.com',
            description: 'Curated premier tech, home, and lifestyle essentials with genuine Amazon US verified deals and price tracking.',
            potentialAction: {
              '@type': 'SearchAction',
              target: 'https://amazonpartnerus.com/?q={search_term_string}',
              'query-input': 'required name=search_term_string',
            },
          }),
        }}
      />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-3 px-4 py-3 rounded-xl bg-zinc-900 border border-amber-500/40 shadow-2xl text-xs text-zinc-100 animate-in slide-in-from-bottom-3">
          <Sparkles className="w-4 h-4 text-amber-400 flex-shrink-0 animate-spin" />
          <span className="font-medium">{toastMessage}</span>
        </div>
      )}

      {/* Main Header */}
      <Header
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        selectedCategory={selectedCategory}
        onSelectCategory={(cat) => {
          setSelectedCategory(cat);
          setQuickFilter('all');
        }}
        categories={CATEGORIES}
        wishlistCount={wishlist.length}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        currentUser={currentUser}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        onSignOut={handleSignOut}
        onOpenAdmin={() => setIsAdminOpen(true)}
        onOpenPolicy={setCurrentPolicy}
      />

      {/* Hero Showcase & Value Proposition */}
      <HeroBanner
        onSelectQuickFilter={(filter) => {
          setQuickFilter(filter);
          if (filter === 'all') setSelectedCategory('All');
        }}
        activeQuickFilter={quickFilter}
        totalProductsCount={products.length}
      />

      {/* Main Content & Products Grid */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-1 w-full">
        {/* Controls Toolbar: Filters & Sorting */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 mb-6 border-b border-zinc-800">
          <div>
            <h2 className="text-xl font-extrabold text-white tracking-tight flex items-center gap-2">
              <span>{selectedCategory === 'All' ? 'Curated US Amazon Catalog' : selectedCategory}</span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-zinc-900 text-amber-400 border border-zinc-800">
                {filteredProducts.length} verified products
              </span>
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              US domestic shipping with direct Amazon A-to-z buyer protection.
            </p>
          </div>

          {/* Filters & Sort Controls */}
          <div className="flex flex-wrap items-center gap-3 text-xs">
            {/* Prime Only Filter Toggle */}
            <label className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-300 cursor-pointer hover:border-zinc-700 transition-colors">
              <input
                type="checkbox"
                checked={primeOnlyFilter}
                onChange={(e) => setPrimeOnlyFilter(e.target.checked)}
                className="accent-amber-500 rounded"
              />
              <span className="font-semibold text-sky-400">Prime 2-Day Only</span>
            </label>

            {/* Price Cap Filter */}
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-300">
              <span className="text-zinc-500">Max:</span>
              <span className="font-bold text-white">${maxPriceFilter}</span>
              <input
                type="range"
                min="50"
                max="2000"
                step="50"
                value={maxPriceFilter}
                onChange={(e) => setMaxPriceFilter(Number(e.target.value))}
                className="w-20 accent-amber-500 h-1 bg-zinc-700 rounded-lg cursor-pointer"
              />
            </div>

            {/* Sort Selector */}
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-300">
              <ArrowUpDown className="w-3.5 h-3.5 text-zinc-500" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-transparent text-zinc-200 font-medium focus:outline-none cursor-pointer"
              >
                <option value="featured" className="bg-zinc-900 text-zinc-200">Sort: Featured Deals</option>
                <option value="price-asc" className="bg-zinc-900 text-zinc-200">Price: Low to High</option>
                <option value="price-desc" className="bg-zinc-900 text-zinc-200">Price: High to Low</option>
                <option value="rating" className="bg-zinc-900 text-zinc-200">Highest Customer Rating</option>
                <option value="discount" className="bg-zinc-900 text-zinc-200">Biggest Discount</option>
              </select>
            </div>
          </div>
        </div>

        {/* Products Grid */}
        {filteredProducts.length === 0 ? (
          <div className="py-20 text-center space-y-4 max-w-md mx-auto">
            <div className="w-16 h-16 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center mx-auto text-zinc-500">
              <Search className="w-8 h-8" />
            </div>
            <h3 className="text-base font-bold text-white">No products matched your criteria</h3>
            <p className="text-xs text-zinc-400">
              Try adjusting your search keywords, lowering the price threshold, or resetting the category filter.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('All');
                setQuickFilter('all');
                setPrimeOnlyFilter(false);
                setMaxPriceFilter(2000);
              }}
              className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs transition-all"
            >
              Reset All Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onOpenDetail={(prod) => setActiveDetailProduct(prod)}
                onBuyAmazon={handleBuyOnAmazon}
                isWishlisted={wishlist.includes(product.id)}
                onToggleWishlist={handleToggleWishlist}
              />
            ))}
          </div>
        )}
      </main>

      {/* Product Detail Modal */}
      <ProductDetailModal
        product={activeDetailProduct}
        onClose={() => setActiveDetailProduct(null)}
        onBuyAmazon={handleBuyOnAmazon}
        isWishlisted={activeDetailProduct ? wishlist.includes(activeDetailProduct.id) : false}
        onToggleWishlist={handleToggleWishlist}
      />

      {/* Wishlist Drawer */}
      <WishlistDrawer
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        products={products}
        wishlistIds={wishlist}
        onRemoveFromWishlist={handleToggleWishlist}
        onClearWishlist={handleClearWishlist}
        onBuyAmazon={handleBuyOnAmazon}
        onOpenDetail={(prod) => setActiveDetailProduct(prod)}
      />

      {/* Google Sign-in Modal */}
      <GoogleAuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onSuccess={handleGoogleSignInSuccess}
      />

      {/* Admin Panel Modal */}
      <AdminPanel
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        products={products}
        onSaveProduct={handleSaveProduct}
        onDeleteProduct={handleDeleteProduct}
        clicks={clicks}
        adminSettings={adminSettings}
        onSaveAdminSettings={handleSaveAdminSettings}
        onBulkUpdateAffiliateTag={handleBulkUpdateAffiliateTag}
        isAuthenticated={isAdminAuthed}
        onAuthenticate={handleAdminAuth}
        onLogoutAdmin={handleLogoutAdmin}
      />

      {/* Legal & Policy Modals */}
      <PolicyModals
        currentPolicy={currentPolicy}
        onClose={() => setCurrentPolicy(null)}
      />

      {/* Footer */}
      <Footer
        onOpenPolicy={setCurrentPolicy}
        onOpenAdmin={() => setIsAdminOpen(true)}
      />
    </div>
  );
}
